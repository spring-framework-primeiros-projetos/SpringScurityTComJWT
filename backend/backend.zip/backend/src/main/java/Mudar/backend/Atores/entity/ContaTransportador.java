package Mudar.backend.Atores.entity;



import Mudar.backend.Emolumento.entity.Contas;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * A classe  ContaTransportador é o identificador do relacionamento entre transportador e as contas que possui.
 * @author Alvaro
 */
@Entity
@Table(name="CONTA_TRANSPORTADOR")
@IdClass(ContaTransportador.class)
public class ContaTransportador implements Serializable {
    
    /**
     * I identificador idcon é o identificador de classe conta do cliente.
     */
    @Id
    @JoinColumn(name="ID_CONTA",unique = true, nullable = true,insertable = false )
    @OneToOne()
    private Contas Idcon;
    
    /**
     * O atributo idtrans é o identificador do saldo do transportador para verificar as possíveis contas para depósito do transportador.
     */
    @Id
    @JoinColumn(name="ID_TRANSPORTADOR",unique = true, nullable = true,insertable = false)
    @OneToOne()
    private Transportador idtrans;

    public ContaTransportador() {
    }

    /**
     * Construtor de ContaTransportador.
     * @param Idcon
     * @param idtrans 
     */
    public ContaTransportador(Contas Idcon, Transportador idtrans) {
        this.Idcon = Idcon;
        this.idtrans = idtrans;
    }

    /**
     * Método getIDCon mostra ID da conta.
     * @return 
     */
    public Contas getIdcon() {
        return Idcon;
    }

    /**
     * Método determina determina o ID da conta.
     * @param Idcon 
     */
    public void setIdcon(Contas Idcon) {
        this.Idcon = Idcon;
    }

    /**
     * Método retorna o ID do transportador.
     * @return ID do transportador.
     */
    public Transportador getIdtrans() {
        return idtrans;
    }

    /**
     * Método que determina o ID do transportador.
     * @param idtrans 
     */
    public void setIdtrans(Transportador idtrans) {
        this.idtrans = idtrans;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.Idcon);
        hash = 23 * hash + Objects.hashCode(this.idtrans);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ContaTransportador other = (ContaTransportador) obj;
        if (!Objects.equals(this.Idcon, other.Idcon)) {
            return false;
        }
        if (!Objects.equals(this.idtrans, other.idtrans)) {
            return false;
        }
        return true;
    }
    
    

}








