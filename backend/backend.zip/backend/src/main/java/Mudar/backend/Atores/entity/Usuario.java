package Mudar.backend.Atores.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.Calendar;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import org.hibernate.validator.constraints.Length;

/**
 * Classe abstrata para criação de usuários na ferramenta
 */
@Entity
@Table(name="USUARIO")
@Inheritance(strategy=InheritanceType.JOINED)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@DiscriminatorColumn(name = "TIPO_USUARIO", length = 1, discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("U")
@SuppressWarnings("PersistenceUnitPresent")
public abstract class Usuario implements  Serializable {

    /**
     * A variável ID alocará a identificação sistêmica do Usuário e seus descendentes.
     */
    @Id
    @Column(name="ID_USUARIO",length = 40, unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID id;
    
    /**
     * A variável nome alocará o nome do Usuário e seus descendentes.
     */
    @Length( max = 255, message = "O nome deve conter o máximo de 255 caracteres.")
    @NotNull(message = "Nome não pode estar vazio.")
    @Column(name="NOME", nullable = false)
    private String nome;

    /**
     * A variável CPF alocará o Cadastro de Pessoa Física (CPF) do Usuário e seus descendentes
     */
    @NotNull(message = "CPF não pode estar vazio.")
    @Column(name="CPF", length = 11, unique = true, nullable = false)
    private long cpf;

    /**
     * A variável telefone alocará o telefone para contato do Usuário e seus descendentes.
     */
    @NotNull(message = "Telefone não pode estar vazio.")
    @Column(name="TELEFONE", length = 12, nullable = true)
    private long telefone;

    /**
     * A variável mail alocará o e-mail do Usuário e seus descendentes.
     */
    @Length(max = 100, message = "O nome deve conter o máximo de 100 caracteres.")
    @NotNull(message = "E-mail não pode estar vazio.")
    @Column(name="E_MAIL", nullable = false,length = 100)
    @Email(message = "E-mail inválido")
    private String mail;

    /**
     * A variável senha alocará a senha do Usuário e seus descendentes, a senha deve ser criptografada de alguma forma de ponta a ponta no sistema.
     */
    @Length(max = 255, message = "A senha deve conter no máximo 255 caracteres.")
    @NotNull(message = "Senha não pode estar vazio.")
    @Column(name="SENHA", nullable = false)
    private String senha;

    /**
     * A variável RG alocará ao valor do Registro Geral (RG) do Usuário e seus descendentes.
     */
    @Length(max = 255, message = "O RG deve conter no máximo 255 caracteres.")
    @NotNull(message = "RG não pode estar vazio.")
    @Column(name="RG", nullable = false)
    private String rg;

    /**
     * A variável nascimento alocará a data de nascimento do Usuário e seus descendentes.
     * 
     */
    @NotNull(message = "Data de nascimento não pode estar vazio.")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.000+0000")
    @Column(name="NASCIMENTO", nullable = false)
    @Temporal(TemporalType.DATE)
    @Past(message = "Data não é Válida para o nascimento")
    private Calendar nascimento;

    /**
     * Construtor vazio não utilizar.
     */
    public Usuario() {
    }

    /**
     * O construtor da classe do Usuário e poderá ser usada como super em seus descendentes.
     * @param id
     * @param nome
     * @param cpf
     * @param nascimento
     * @param telefone
     * @param mail
     * @param rg
     * @param senha
     */
    public Usuario(UUID id, String nome, long cpf, long telefone, String mail, String senha, String rg, Calendar nascimento) {
    this.id =  id;
    this.nome = nome;
    this.cpf = cpf;
    this.telefone = telefone;
    this.mail = mail;
    this.senha = senha;
    this.rg = rg;
    this.nascimento = nascimento;
}

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public long getTelefone() {
        return telefone;
    }

    public void setTelefone(long telefone) {
        this.telefone = telefone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public Calendar getNascimento() {
        return nascimento;
    }

    public void setNascimento(Calendar nascimento) {
        this.nascimento = nascimento;
    }

        
}




























