/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Atores.repository;

import Mudar.backend.Atores.entity.ContaTransportador;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author Alvaro
 */
public interface ContaTransportadorRepository extends JpaRepository<ContaTransportador, ContaTransportador>{
   
     /**
     * Método que retorna a classe ContaTransportador pela busca através do ID do Transportador.
     * @param id
     * @return
     */
    @Query(value = "SELECT * FROM conta_transportador WHERE id_transportador = ?1",nativeQuery = true)
    ContaTransportador findByidtrans(UUID id);
    
    /**
     * Método que retorna a classe ContaTransportador pela busca através do ID da conta.
     * @param id
     * @return
     */
    @Query(value = "SELECT * FROM conta_transportador WHERE id_conta = ?1",nativeQuery = true)
    ContaTransportador findByidconta(UUID id);
}
