/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Validator;

import java.io.Serializable;
import java.util.Calendar;
import java.util.UUID;


/**
 *
 * @author Alvaro
 */
public class IDMaker  implements Serializable, Comparable<UUID>{

    DateValidator dv = new DateValidator();
    @Override
    public int compareTo(UUID o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
      public UUID GeraID (){
        UUID id = UUID.randomUUID();
        String sid = id.toString();
        return UUID.randomUUID();
      }
      public UUID GeraIDservico (){
        UUID variavel = UUID.randomUUID();
          long lid = variavel.getLeastSignificantBits();
          long data;
          Calendar hoje = Calendar.getInstance();
         UUID idd;
        idd = new UUID(dv.getdatetime(), lid);
        return idd;
      }
    
}
