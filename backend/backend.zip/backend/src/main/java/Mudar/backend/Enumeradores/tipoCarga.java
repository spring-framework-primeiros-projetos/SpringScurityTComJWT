/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Enumeradores;

/**
 * A Classe enumeradora informa uma gama de formatos de transportes para os produtos solicitados.
 * @author Alvaro
 */
public enum tipoCarga {
    
    /**
     * Esse tipo de carga corresponde, em sua grande maioria, ao transporte de matérias-primas, como:"Soja, Arroz, Milho, Feijão, Cereais em geral e outros".
     * Além disso, os tipos de caminhão mais utilizados nessa modalidade são o Truck e a Carreta (cavalo simples ou LS), Bitrem e Rodotrem.
     * O modelo da carroceria pode ser aberto, graneleiro ou grade alta.
     */
    Granel_Solido(1),
    
    /**
     * Granel líquido (não perigoso)
     * Já essa carga, como o próprio nome sugere é líquida e não é considerada perigosa. Corresponde a: Sucos, àgua potável, leite, refrigerante, entre outros produtos líquidos.
     * Muitos não sabem, mas essa mercadoria deve ser levada em caminhões bem específicos.
     * É necessário uma carroceria que contenha tanque de aço, como: caminhão cisterna, carro-tanque ou caminhão pipa.
     * Atualmente, os caminhões pipas são muito utilizados para o abastecimento de água e até para a lavagem de ruas.
     */
    Granel_Liquido(2),
    
    /**
     * As cargas frigoríficas ou também chamadas de refrigeradas, se encaixam dentro de duas categorias: a perecível e a congelada.
     * Vale lembrar, que esse tipo de mercadoria necessidade de cuidados bastante especiais e, claro, cumprir todas as normas e leis, já que se trata de produtos de ingestão humana
     * As cargas frigoríficas perecíveis enfrentam alguns desafios: não é possível transportar esse produto para longas distâncias.
     * Isso porque esse tipo de mercadoria pode estragar ao longo do tempo, já que passa por um processo de redução da temperatura, porém não há a formação de gelo.
     * No caso de transporte pelo modal rodoviário, a carroceria ideal é a baú refrigerado, que possui um aparelho de refrigeração de temperatura entre 0 e -10°C.
     * Contudo, devido ao curto ciclo de vida desse tipo de carga, é comum que o transporte seja feito pelo modal rodoviário, que permite entrega mais rápida.
     */ 
    Frigorificada_pereciveis(3),
    
    /**
     * Podem ser definidas como carga perecível congelada os produtos que passaram por um processo de diminuição de temperatura, ocorrendo a formação de gelo.
     * No entanto, transportar congelados também requer muito cuidado: é necessário ficar atento à temperatura, armazenamento e manutenção da mercadoria. 
     * Esses produtos são transportados em caminhões completamente refrigerados, a fim de garantir a conservação e o congelamento ideal da carga até o destino final.
     * Além disso, o ideal é usar a carroceria baú frigorífico, que é um modelo fechado. Ela conta com aparelho de refrigeração de -15°C a -20°C
     */
    Frigorificada_congeladas(4),
    
    /**
     * Existem caminhões projetados especificamente para o uso de contêineres, que nada mais são que caixas de ferro de diferentes dimensões.
     * Os contêineres são muito versáteis, podendo transportar produtos secos, frágeis e até mesmo carga viva.A grande vantagem do uso de contêineres está na fluidez proporcionada, com a caixa podendo ser repassada do caminhão para um navio ou trem, por exemplo, de forma rápida e segura.
     */
    Conteinerizada(5),
    
    Carga_Geral(6),
    
    /**
     * A corresponde ao carregamento formado por conglomerados homogêneos (iguais) de mercadorias, de carga geral, sem acondicionamento específico, cujo volume ou quantidade possibilita o transporte em lotes, em um único embarque (exemplo: veículos)
     */
    Neogranel(7),
    /**
     * Esses tipos de carga refere-se aos produtos industrializados e não perecíveis.
     * Além disso, o transporte pode ser feito independentemente da estação do ano ou do clima, já que não precisa de refrigeração.
     * Dessa forma, se trata de uma carga bastante versátil.
     * Para essa categoria, geralmente, é utilizada a carroceria baú – ela é apropriada para transportar caixas, sacas, fardos, embalagens e outros.
     * No entanto, o transporte ideal para locomover é o VUC (Veículo Urbano de Carga) e até Carreta LS – caminhões mais populares para isso.
     * Além disso, o mais indicado para facilitar o manuseio dessas cargas é o pallets (ou paletes).
     */
    Carga_Seca(8),
    
    /**
     * As cargas perigosas são aquelas que representam riscos à saúde das pessoas, ao meio ambiente ou à segurança pública, sejam eles encontrados na natureza ou produzidos.
     * Para atuar com esse tipo de transporte, é necessário ter caminhões preparados para o produto específico.
     * Além disso, o veículo deve apresentar símbolos que sinalizem a classificação do risco.
     */
    Perigosa_granel_sólido(21),
    
    /**
     * As cargas perigosas são aquelas que representam riscos à saúde das pessoas, ao meio ambiente ou à segurança pública, sejam eles encontrados na natureza ou produzidos.
     * Para atuar com esse tipo de transporte, é necessário ter caminhões preparados para o produto específico.
     * Além disso, o veículo deve apresentar símbolos que sinalizem a classificação do risco.
     */
    Perigosa_Granel_Liquido(22),
    
    /**
     * As cargas perigosas são aquelas que representam riscos à saúde das pessoas, ao meio ambiente ou à segurança pública, sejam eles encontrados na natureza ou produzidos.
     * Para atuar com esse tipo de transporte, é necessário ter caminhões preparados para o produto específico.
     * Além disso, o veículo deve apresentar símbolos que sinalizem a classificação do risco.
     */
    Perigosa_Carga_Frigorificada(23),
    
    /**
     * As cargas perigosas são aquelas que representam riscos à saúde das pessoas, ao meio ambiente ou à segurança pública, sejam eles encontrados na natureza ou produzidos.
     * Para atuar com esse tipo de transporte, é necessário ter caminhões preparados para o produto específico.
     * Além disso, o veículo deve apresentar símbolos que sinalizem a classificação do risco.
     */
    Perigosa_Conteinerizada (24),
    
    /**
     * As cargas perigosas são aquelas que representam riscos à saúde das pessoas, ao meio ambiente ou à segurança pública, sejam eles encontrados na natureza ou produzidos.
     * Para atuar com esse tipo de transporte, é necessário ter caminhões preparados para o produto específico.
     * Além disso, o veículo deve apresentar símbolos que sinalizem a classificação do risco.
     */
    Perigosa_Carga_geral(25);
    
    int valorTipoCarga;

    private tipoCarga(int valorTipoCarga) {
        this.valorTipoCarga = valorTipoCarga;
    }
    
    
}
