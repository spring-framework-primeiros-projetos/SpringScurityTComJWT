package Mudar.backend.Enumeradores;

/**
 * O enumerador Pagamento filho do enumerador Status, tem por objetivo listar a forma de pagamento do cliente de acordo com o terceiro.
 * 
 * Status Atual	=> Próximo status possível
 * pending	=> paid, canceled, partially_paid, expired, authorized
 * paid	=> refunded, in_protest, chargeback
 * canceled	=> _paid
 * partially_paid	=> paid
 * expired	=> _paid
 * authorized	=> canceled, paid
 * refunded	=>
 * in_protest	=> paid, chargeback
 * chargeback	=>
 */

public enum Pagamento {

	/**
	 * pending / pendente => Quando a fatura ainda não foi paga.
	 */
	pending,

	/**
	 * paid / paga => Fatura paga.
	 */
	paid,

	/**
	 * draft / rascunho => Ao criar uma fatura pelo painel somente, pode usar a chave "rascunho" para salvar os dados de uma fatura, a fatura em si ainda não foi gerada, não há uma cobrança, apenas dados salvos que podem se tornar uma cobrança
	 */
	draft,

	/**
	 * partially_paid / parcialmente paga => Fatura parcialmente paga; em geral, quando um boleto não é pago em seu valor total ou não é pago o valor da multa e juros pelo atraso. (pagamento após o vencimento).
	 */
	partially_paid,

	/**
	 * refunded / reembolsada => Fatura reembolsada (apenas para pagamentos por cartão de crédito).
	 */
	refunded,

	/**
	 * expired / expirada => A cobrança atingiu o tempo limite após o vencimento e expirou; não pode mais ser paga.
	 */
	expired,

	/**
	 * in_protest / em protesto => Quando uma fatura já paga (paid) recebe uma notificação de não reconhecimento da compra (apenas para pagamentos por cartão de crédito). Você pode gerenciar os pedidos de contestações de compra pelo menu "Chargeback" do painel
	 */
	in_protest,

	/**
	 * chargeback / contestada => Quando o status (in_protest) é reembolsado para o cliente, que ganhou a disputa do chargeback, significa que sua fatura foi contestada e nesta etapa, já não poderá mais recorrer.
	 */
	chargeback,

	/**
	 * in_analysis / em análise => Recurso da iugu que acrescenta uma etapa a mais ao pagamento da sua fatura entre o (pending) e o (paid). Recurso opcional; você pode ativar/desativar a qualquer momento.
	 */
	inanalysis,

	/**
	 * _paid = boletos pagos levam de 1 dia à 3 dias úteis para compensar e então constar como pago na iugu, caso, dentro deste intervalo de tempo, entre o boleto já estar pago mas não compensado, a fatura pode vir a cancelar ou expirar, mas será atualizado para pago, quando entrar a compensação.
	 */
	_paid;
        
        

}
