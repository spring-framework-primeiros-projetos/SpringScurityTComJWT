package Mudar.backend.Frete.entity;

import Mudar.backend.Enumeradores.tipoCarga;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A Interface Construtor foi gerada para conglomerar todas a possibilidade de 
 * fretes para cobrar do ator Solicitante.
 */
@Entity
@Table(name="ORCAMENTO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_servico", length = 3, discriminatorType = DiscriminatorType.INTEGER)
@DiscriminatorValue("0")
public abstract class ConstrutorFretes implements Serializable {

    /**
     * A Variável ID é o identificador do orçamento do serviço.
     */
    @Id
    @NotNull(message = "ID não pode esta vazio.")
    @Column(name="ID_SERVICO", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID id;

    /**
     * Construtor vazio não utilizar.
     */
    public ConstrutorFretes() {
    }

    /**
     * O construtor para inicializar o construtor e descendentes.
     * @param id 
     */
    public ConstrutorFretes(UUID id) {
        this.id = id;
    }

    /**
     * O método retorna o ID da construtor.
     * @return 
     */
    public UUID getId() {
        return id;
    }

    /**
     * O método determina o ID da construtor.
     * @param id 
     */
    public void setId(UUID id) {
        this.id = id;
    }
    
    public abstract CustoAlimentacao ConstrutorAlimentacao( float custo_total);
    public abstract CustoCarga ConstrutorCarga(tipoCarga tipoCarga,float distancia,int eixo,float cargaDescarga,float totalCarga);
    public abstract CustoPedagio ConstrutorPedagio(float valorTotal,int qtd); 
}
