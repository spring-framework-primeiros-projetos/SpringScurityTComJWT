/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Endereco;

import Mudar.backend.Enumeradores.Estado;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 * A classe Endereço busca colocar o endereço do cliente registrado no sistema facilitando a busca pelo serviço.
 */
@Embeddable
@Table(name="ENDERECO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public class DestinoEndereco implements Serializable {


    /**
     * A variável local rua alocará a rua passada pelo cliente.
     */
    @Column(name="Destino_RUA", unique = false, nullable = true,insertable = false)
    private String rua;

    /**
     * A variável local numero alocará o número do endereço
     */
    @Column(name="Destino_NUMERO",nullable = true)
    private String numero;

    /**
     * A variável local complemento alocará o complemento do endereço
     */
    @Column(name="Destino_COMPLEMENTO", unique = false, nullable = true,insertable = false)
    private String complemento;

    /**
     * A variável local CEP alocará o CEP do endereço.
     */
    @Column(name="Destino_CEP", unique = false, nullable = true,insertable = false)
    private int cep;

    /**
     * A variável local Bairro alocará o bairro do endereço.
     */
    @Column(name="Destino_BAIRRO", unique = false, nullable = true,insertable = false)
    private String bairro;

    /**
     * A variável local Cidade alocará a cidade do endereço.
     */
    @Column(name="Destino_CIDADE", unique = false, nullable = true,insertable = false)
    private String cidade;

    /**
     * A variável local estado alocará o estado do endereço.
     */
    @Column(name="Destino_ESTADO", unique = false, nullable = true,insertable = false)
    @Enumerated(EnumType.STRING)
    private Estado estado;

    /**
     * Construtor vazio, não utilizar.
     */
    public DestinoEndereco() {
    }

    
    /**
     * 
     * @param rua
     * @param numero
     * @param complemento
     * @param cep
     * @param bairro
     * @param cidade
     * @param estado 
     */
    public DestinoEndereco(String rua, String numero, String complemento, int cep, String bairro, String cidade, Estado estado) {
        this.rua = rua;
        this.numero = numero;
        this.complemento = complemento;
        this.cep = cep;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    
}
