/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Atores.Controller;


import Mudar.backend.Atores.entity.Solicitante;
import Mudar.backend.Atores.repository.SolicitanteRepository;
import Mudar.backend.Validator.CpfCnpjUtils;
import Mudar.backend.Validator.DateValidator;
import Mudar.backend.Validator.IDMaker;
import Mudar.backend.Validator.TextValidator;
import java.text.SimpleDateFormat;
import java.util.UUID;
import javax.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Alvaro
 */
@RestController
@RequestMapping("/solicitante")
public class SolicitanteController {
    @Autowired
    private SolicitanteRepository bdsolicitante;
    
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private final IDMaker id = new IDMaker();
    private DateValidator dv = new DateValidator();
    private TextValidator txt = new TextValidator();
    
    @GetMapping(value = "/teste")
    public ResponseEntity<String> solicitante(){
        return ResponseEntity.ok("CRUD de solicitante possível");
    }

    /**
     * Método para cadastro no banco de Solicitante.
     * 
     * @param solicitante
     * @return
     */
    @PostMapping("")
    public ResponseEntity<Object> cadastra(@Valid  @RequestBody Solicitante solicitante) {
        solicitante.setId(id.GeraID());
        solicitante.setNome(TextValidator.toTitledCase(solicitante.getNome()));
        solicitante.setMail(solicitante.getMail().toLowerCase());
        if(!CpfCnpjUtils.isValid(Long.toString(solicitante.getCpf()))){
            return new ResponseEntity<>("CPF inválido", HttpStatus.BAD_REQUEST);
        }
        try {
        return ResponseEntity.ok(bdsolicitante.getOne(bdsolicitante.save(solicitante).getId()));
        } 
        catch (Exception e ) {
            return new ResponseEntity<>("Dados já cadastrados ", HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Método para busca no banco um Solicitante.
     * @param id
     * @return 
     */
    @GetMapping("/{id}")
    public ResponseEntity<Object> Buscar(@Valid  @PathVariable UUID id) {
            if (bdsolicitante.existsById(id)) {
                System.out.println("Encontrado para retorno.");
                return ResponseEntity.ok(bdsolicitante.getOne(id));
            }
            return ResponseEntity.notFound().build();
    }
    
    /**
     * Método que atualiza no banco os dados do Solicitante.
     * @param solicitante
     * @return
     */
    @PutMapping("")
    public ResponseEntity<Object> Atualizar(@Valid @RequestBody Solicitante solicitante) {
        if (bdsolicitante.existsById(solicitante.getId())) {
            System.out.println("Encontrado para alteração.");
            solicitante.setNome(TextValidator.toTitledCase(solicitante.getNome()));
            solicitante.setMail(solicitante.getMail().toLowerCase());
            if(!CpfCnpjUtils.isValid(Long.toString(solicitante.getCpf()))){
                return new ResponseEntity<>("CPF inválido", HttpStatus.BAD_REQUEST);
            }
            Solicitante existente = bdsolicitante.getOne(solicitante.getId());
            BeanUtils.copyProperties(solicitante, existente, solicitante.getId().toString());
            existente = bdsolicitante.save(existente);
            return ResponseEntity.ok(existente);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Método que deleta no banco os dados do Solicitante.
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> Deletar(@Valid  @PathVariable UUID id){
        if (bdsolicitante.existsById(id)) {
                System.out.println("Encontrado para Deleção.");
                bdsolicitante.deleteById(id);
                return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}















