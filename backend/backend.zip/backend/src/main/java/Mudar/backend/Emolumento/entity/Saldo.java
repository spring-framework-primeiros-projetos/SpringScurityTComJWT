package Mudar.backend.Emolumento.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Alvaro
 */
@Entity
@Table(name = "SALDO")
public class Saldo implements Serializable {
    
    @Id
    @NotNull
    @NotBlank   
    @Column(name="ID_SALDO", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID IdSal;
    
    @NotNull
    @NotBlank
    @Column(name="SALDO")
    private double saldo;

    public Saldo() {
    }

    public Saldo(UUID IdSal, double saldo) {
        this.IdSal = IdSal;
        this.saldo = saldo;
    }

    /**
     * O método retorna o ID do saldo do transportador.
     * @return 
     */
    public UUID getIdSal() {
        return IdSal;
    }

    /**
     * O método determina o valor do ID do saldo do transportador.
     * @param IdSal 
     */
    public void setIdSal(UUID IdSal) {
        this.IdSal = IdSal;
    }

    /**
     * O método retorna o saldo do cliente.
     * @return 
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * O método determina o saldo do cliente.
     * @param saldo 
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    } 
}












































































