package Mudar.backend.Emolumento.entity;

import Mudar.backend.Atores.entity.Transportador;
import Mudar.backend.Atores.entity.Usuario;
import Mudar.backend.Enumeradores.Pagamento;
import java.util.Date;
import java.util.UUID;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/**
 *
 * @author Alvaro
 */
//@Entity
@Table(name="EMOLUMENTO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TIPO_EMOLUMENTO", length = 3, discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("GPE")    // Abreviação para gera pagamento entrada.
    public class GeraPagamento extends Proventos {

    /**
     * Construtor vazio, não utilizar.
     */
    public GeraPagamento() {
    }

    /**
     * O construtor GeraPagamento será utilizado paga gerar variáveis da classe.
     * @param id
     * @param gerado
     * @param pago
     * @param status
     * @param valor
     * @param pagante
     * @param destinatario 
     */
    public GeraPagamento(UUID id, Date gerado, Date pago, Pagamento status, Valores valor, Usuario pagante, Transportador destinatario) {
        super(id, gerado, pago, status, valor, pagante, destinatario);
    }

    
    /**
     * 
     * @return 
     */
    @Override
    public GeraPagamento pagamento() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}































































































































