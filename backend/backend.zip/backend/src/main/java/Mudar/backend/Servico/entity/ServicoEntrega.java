package Mudar.backend.Servico.entity;

import Mudar.backend.Emolumento.entity.Proventos;
import Mudar.backend.Endereco.DestinoEndereco;
import Mudar.backend.Endereco.OrigemEndereco;
import Mudar.backend.Enumeradores.Pagamento;
import Mudar.backend.Enumeradores.Servico;
import Mudar.backend.Frete.entity.ConstrutorFretes;
import Mudar.backend.Tranporte.entity.VeiculoTransportador;
import java.util.Date;
import java.util.UUID;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * A classe especializada ServicoEntrega trata de registrar no sistema o serviço solicitado pelo ator Solicitante para ser atendido pelo ator transportador no sistema.
 */
@Entity
@Table(name="DESPACHO")
@DiscriminatorColumn(name = "TIPO_DESPACHO", length = 1, discriminatorType = DiscriminatorType.INTEGER)
@DiscriminatorValue("200")
public class ServicoEntrega extends Despacho {

    /**
     * O construtor esta vazio, não utilizar.
     */
    public ServicoEntrega() {
    }

    /**
     * 
     * @param id
     * @param EnderecoOrigem
     * @param EnderecoDestino
     * @param frete
     * @param statusServico
     * @param statusPagamento
     * @param Atendimento
     * @param Distancia
     * @param Transportador
     * @param Orcamento 
     */
     public ServicoEntrega(UUID id, OrigemEndereco EnderecoOrigem, DestinoEndereco EnderecoDestino, ConstrutorFretes frete, Servico statusServico, Pagamento statusPagamento, Date Atendimento, float Distancia, VeiculoTransportador Transportador, Proventos Orcamento) {
        super(id, EnderecoOrigem, EnderecoDestino, frete, statusServico, statusPagamento, Atendimento, Distancia, Transportador, Orcamento);
    }

    @Override
    public float CalculaTotal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}






































































