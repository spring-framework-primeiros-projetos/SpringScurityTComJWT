package Mudar.backend.Atores.entity;


import Mudar.backend.Enumeradores.Carteira;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Calendar;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

/**
 * A Classe Transportador representa o ator dentro da ferramenta com os dados básicos para atender o serviço solicitado pelo sistema.
 * @author Alvaro
 */
@Entity
@Table(name="TRANSPORTADOR")
@DiscriminatorColumn(name = "TIPO_USUARIO", length = 1, discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("T")
@SuppressWarnings("PersistenceUnitPresent")
public class Transportador extends Usuario{
    

    /**
     * A variável carteira alocará o número carteira de motorista do cliente.
     */
    
    @Column(name="CARTEIRA",length = 12, unique = true)
    private long carteira;

    /**
     * A classe validade alocará a validade da carteira de motorista.
     */
    //@CompositeMember(value = "CARTEIRA")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.000+0000")
    @Future(message = "Data da Validade da carteira não é válida.")
    @Column(name="CARTEIRA_VALIDADE")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Calendar validade;

    /**
     * A variável emissão alocará a data de emissão da carteira.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.000+0000")
    @Past(message = "Data de Emissão da carteira não é válida.")
    @Column(name="CARTEIRA_EMISSAO")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Calendar emissao;

    public Transportador() {
    }

    /**
     * A variável tipo alocará o tipo de carteira do Transportador.
     * 
     */
    @Enumerated(EnumType.STRING)
    @Column(name="CARTEIRA_TIPO", length = 2, columnDefinition = "char(1)")
    private Carteira tipo;
    
    /**
     *
     * @param id
     */
    public void ServiçoDisponível(Transportador id) {

    }
    /**
     * 
     * @param carteira
     * @param validade
     * @param emissao
     * @param tipo
     * @param id
     * @param nome
     * @param cpf
     * @param telefone
     * @param mail
     * @param senha
     * @param rg
     * @param nascimento 
     */
    public Transportador(UUID id, String nome, int cpf, int telefone, String mail, String senha, String rg, Calendar nascimento,long carteira, Calendar validade, Calendar emissao, Carteira tipo) {
        super(id, nome, cpf, telefone, mail, senha, rg, nascimento);
        this.carteira = carteira;
        this.validade = validade;
        this.emissao = emissao;
        this.tipo = tipo;
    }

    public long getCarteira() {
        return carteira;
    }

    public void setCarteira(long carteira) {
        this.carteira = carteira;
    }

    public Calendar getValidade() {
        return validade;
    }

    public void setValidade(Calendar validade) {
        this.validade = validade;
    }

    public Calendar getEmissao() {
        return emissao;
    }

    public void setEmissao(Calendar emissao) {
        this.emissao = emissao;
    }

    public Carteira getTipo() {
        return tipo;
    }

    public void setTipo(Carteira tipo) {
        this.tipo = tipo;
    }
    
    
}
