package Mudar.backend.Frete.entity;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

/**
 * A Classe especializa CustoPedágio retornará a consulta a uma API com o valor total e fracionado do pedágio que a carga passará.
 */
@Entity
@Table(name="ORCAMENTO")
public class CustoPedagio extends Custo {
    
    /**
     * A variável valorPedagio aloca Total gasto nos pedágio no transporte da carga.
     */
    @Length( max = 20, message = "O valor total deve conter o máximo de 20 caracteres.")
    @NotNull(message = "O total do pedágio não pode estar vazio.")
    @Column(name = "VALOR_TOTAL_PEDAGIO",length = 20)
    private float valorTotal;
    
    /**
     * A variável aloca o quantidade total de pedágios para o transporte.
     */
    @Length( max = 3, message = "A quantidade deve conter o máximo de 3 caracteres.")
    @NotNull(message = "A quantidade de  pedágios não pode estar vazio.")
    @Column(name = "QTD_PEDAGIO", length = 3)
    private int  qtd;

    /**
     * Construtor vazio não utilizar
     */
    public CustoPedagio() {
    }

    public CustoPedagio(float valorTotal, int qtd) {
        this.valorTotal = valorTotal;
        this.qtd = qtd;
    }

    /**
     * Construtor  para o custo do pedágio de forma totalizada e quantidade de pedágio que passará até o destino.
     * @param valorTotal
     * @param qtd 
     * @param id 
     */
    public CustoPedagio(UUID id,float valorTotal, int qtd) {    
        super(id);
        this.valorTotal = valorTotal;
        this.qtd = qtd;
    }

    /**
     * O método retorna o Total gasto nos pedágio no transporte da carga.
     * @return 
     */
    public float getValorTotal() {
        return valorTotal;
    }

    /**
     * O método determina o Total gasto nos pedágio no transporte da carga.
     * @param valorTotal 
     */
    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    /**
     * O método retorna a quantidade total de pedágios para o transporte.
     * @return 
     */
    public int getQtd() {
        return qtd;
    }

    /**
     * O método determina a quantidade total de pedágios para o transporte.
     * @param qtd 
     */
    public void setQtd(int qtd) {
        this.qtd = qtd;
    }
    
    

}
