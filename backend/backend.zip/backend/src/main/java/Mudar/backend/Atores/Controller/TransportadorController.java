/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Atores.Controller;

import Mudar.backend.Atores.entity.Transportador;
import Mudar.backend.Atores.repository.TransportadorRepository;
import Mudar.backend.Validator.CpfCnpjUtils;
import Mudar.backend.Validator.DateValidator;
import Mudar.backend.Validator.IDMaker;
import Mudar.backend.Validator.TextValidator;
import Mudar.backend.Validator.ValidarCNH;
import java.text.SimpleDateFormat;
import java.util.UUID;
import javax.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Alvaro
 */
@RestController
@RequestMapping("/transportador")
public class TransportadorController {
    @Autowired
    private TransportadorRepository bdtransportador;
    
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private final IDMaker id = new IDMaker();
    private DateValidator dv = new DateValidator();
    private TextValidator txt = new TextValidator();
    
    @GetMapping(value = "/teste")
    public ResponseEntity<String> solicitante(){
        return ResponseEntity.ok("CRUD de transportador possível");
    }

    /**
     * Método para cadastro no banco de Solicitante.
     * 
     * @param transportador
     * @return
     */
    @PostMapping("")
    public ResponseEntity<Object> cadastra( @Valid @RequestBody Transportador transportador) {
        transportador.setId(id.GeraID());
        transportador.setNome(TextValidator.toTitledCase(transportador.getNome()));
        transportador.setMail(transportador.getMail().toLowerCase());
        if(!CpfCnpjUtils.isValid(Long.toString(transportador.getCpf()))){
            return new ResponseEntity<>("CPF inválido", HttpStatus.BAD_REQUEST);
        }
        if(!ValidarCNH.validaCNH(Long.toString(transportador.getCarteira()))){
            return new ResponseEntity<>("CNH inválida", HttpStatus.BAD_REQUEST);
        }
        try {
        return ResponseEntity.ok(bdtransportador.getOne(bdtransportador.save(transportador).getId()));
        } 
        catch (Exception e ) {
            return new ResponseEntity<>("Dados já cadastrados ", HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Método para busca no banco um Solicitante.
     * @param id
     * @return 
     */
    @GetMapping("/{id}")
    public ResponseEntity<Object> Buscar(@Valid  @PathVariable UUID id) {
            if (bdtransportador.existsById(id)) {
                System.out.println("Encontrado para retorno.");
                return ResponseEntity.ok(bdtransportador.getOne(id));
            }return ResponseEntity.notFound().build();
    }
    
    /**
     * Método que atualiza no banco os dados do Solicitante.
     * @param transportador
     * @return
     */
    @PutMapping("")
    public ResponseEntity<Object> Atualizar(@Valid @RequestBody Transportador transportador) {
        if (bdtransportador.existsById(transportador.getId())) {
            System.out.println("Encontrado para alteração.");
            transportador.setNome(TextValidator.toTitledCase(transportador.getNome()));
            transportador.setMail(transportador.getMail().toLowerCase());
             transportador.setNome(TextValidator.toTitledCase(transportador.getNome()));
            transportador.setMail(transportador.getMail().toLowerCase());
            if(!CpfCnpjUtils.isValid(Long.toString(transportador.getCpf()))){
                return new ResponseEntity<>("CPF inválido", HttpStatus.BAD_REQUEST);
            }
            if(!ValidarCNH.validaCNH(Long.toString(transportador.getCarteira()))){
                return new ResponseEntity<>("CNH inválida", HttpStatus.BAD_REQUEST);
            }
            Transportador existente = bdtransportador.getOne(transportador.getId());
            BeanUtils.copyProperties(transportador, existente, transportador.getId().toString());
            existente = bdtransportador.save(existente);
            return ResponseEntity.ok(existente);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Método que deleta no banco os dados do Solicitante.
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> Deletar(@Valid  @PathVariable UUID id){
        if (bdtransportador.existsById(id)) {
            System.out.println("Encontrado para Deleção.");
            return ResponseEntity.noContent().build();
        }return ResponseEntity.notFound().build();
    }
}
 	 	
