/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Atores.repository;

import Mudar.backend.Atores.entity.SaldoTransportador;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author Alvaro
 */
public interface SaldoTransportadorRepository extends JpaRepository<SaldoTransportador,SaldoTransportador>{
     /**
     * Método que retorna a classe SaldoTransportador pela busca através do ID do saldo.
     * @param id
     * @return
     */
    @Query(value = "SELECT * FROM saldo_transportador WHERE id_trans = ?1",nativeQuery = true)
    SaldoTransportador findByidtrans(UUID id);
    
    /**
     * Método que retorna a classe SaldoTransportador pela busca através do ID do saldo.
     * @param id
     * @return
     */
    @Query(value = "SELECT * FROM saldo_transportador WHERE id_saldo = ?1",nativeQuery = true)
    SaldoTransportador findByidSal(UUID id);;
}



































































































