package Mudar.backend.Emolumento.entity;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Forma de pagamento por Credito exclusivo do Solicitante que possibilita a forma de pagamento parcelada.
 */
@Entity
@Table(name="CREDITO")
public class Credito extends Valores {

    /**
     * A variável juros alocará o acrécimo de juros na forma de pagamento.
     */
    @NotNull(message = "Juros não pode estar vazio.")
    @Column(name="Juros",length = 9, unique = false, nullable = true,insertable = false)
    private float juros;

    /**
     * Método para cotação de juros para o pagamento de crédito.
     * @param ValorPresente - Deve-se colocar o valor total do serviço.
     * @param TaxaJuros - Deve-se colocar o valor do juros com um float.
     * @param tempo - Deve-se colocar o valor de tempo em meses como um inteiro
     * @return 
     */
    public float TotalJuros(float ValorPresente, float TaxaJuros,int tempo){
        float montante, aux;
        aux = (float) Math.pow((1 + (TaxaJuros/100)), tempo);
        montante = ValorPresente * aux;
        return montante - ValorPresente;
    }    

    /**
     * Construtor incompleto não utilizar
     * @param juros 
     */
    public Credito(float juros) {
        this.juros = juros;
    }

    /**
     * Construtor vazio não utilizar.
     */
    public Credito() {
    }
    /**
     * O construtor será utilizado como super nos descentes para criação das variáveis.
     * @param juros
     * @param id
     * @param valor 
     */
    public Credito(UUID id, float valor,float juros) {
        super(id, valor);
        this.juros = juros;
    }

}






















































































































































































































































































