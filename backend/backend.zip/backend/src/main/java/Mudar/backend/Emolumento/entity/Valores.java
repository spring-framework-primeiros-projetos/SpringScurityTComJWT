package Mudar.backend.Emolumento.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Classe mãe que determina a forma de pagamento do serviço
 */
@Entity
@Table(name="VALORES")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public abstract class Valores implements Serializable {

    /**
     * A variável ID alocará a identificação sistêmica do Usuário e seus descendentes.
     */
    @Id
    @NotNull(message = "ID não pode estar vazio.")
    @Column(name="ID_EMOLUMENTO", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID id;
    
    /**
     * A váriavel valor aloca o valor para cobrança do cliente.
     */
    @NotNull(message = "Valor não pode estar vazio.")
    @Column(name="VALOR",length = 9, unique = false, nullable = true,insertable = false)
    private float valor;

    /**
     * Construtor vazio, não utilizar.
     */
    public Valores() {
    }

    /**
     * O construtor Valores será o construtor que poderá ser utilizada como super em seus descendentes.
     * @param id
     * @param valor 
     */
    public Valores(UUID id, float valor) {
        this.id = id;
        this.valor = valor;
    }

    /**
     * O método retorna o ID da Classe.
     * @return 
     */
    public UUID getId() {
        return id;
    }

    /**
     * O método determina o ID da Classe
     * @param id 
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * O método retorna o valor do serviço registrado na classe.
     * @return 
     */
    public float getValor() {
        return valor;
    }

    /**
     * O método determina o valor registrado na classe.
     * @param valor 
     */
    public void setValor(float valor) {
        this.valor = valor;
    }
    
}


































































































































































