package Mudar.backend.Enumeradores;


/**
 * A classe enumeradora Carroceira enumera as possíveis carrocerias de veículos de acordo com o DETRAN.
 */
public enum TipoCarroceria {

	ambulancia(101),

	basculante(102),

	bombeiro(104),

	buggy(105),

	cabDupla(106),

	carroceriaAberta(107),

	carroceriaFechada(108),

	chassiConteiner(109),

	conversivel(110),

	funeral(111),

	furgao(112),

	limusine(115),

	mecanismoOperacional(116),

	prancha(118),

	sideCar(119),

	silo(120),

	tanque(121),

	trailler(122),

	transporteMilitar(123),

	transportePresos(124),

	transporteRecreativo(125),

	transporteTrabalho(126),

	conteiner_carrocAber(127),

	pranchaConteiner(128),

	cabEstendida(129),

	trioEletrico(130),

	dolly(131),

	intercambiavel(132),

	RollonRolloff(133),

	carrocAber_cabDupla(134),

	carrocAber_cabEstendida(135),

	carrocAber_cabSuplementar(136),

	carrocFech_cabDupla(137),

	carrocFech_cabEstendida(138),

	carrocFech_cabSuplementar(139),

	carrocAber_intercambiavel(140),

	cabDupla_Inacabada(141),

	MecOperac_cabDupla(142),

	transporteToras(143),

	inacabada_cabEstendida(144),

	carrocAber_mecOperac(145),

	carrocFech_mecOperac(146),

	tanque_mecOperac(147),

	prancha_mecOperac(148),

	carrocAber_mecOperac_CabDupla(149),

	carrocAber_mecOperac_cabEstendida(150),

	carrocAberta_mecOperacional_cabSuplementar(151),

	carrocFech_mecOperacional_cabDupla(152),

	carrocFech_mecOperac_cabEstendida(153),

	carrocFech_mecOperac_cabSuplementar(154),

	Tanque_cabDupla(155),

	tanque_cabEstendida(156),

	tanque_cabSuplementar(157),

	tanque_mecOperac_cabDupla(158),

	tanque_mecOperac_CabEstendida(159),

	tanque_mecOperac_cabSuplementar(160),

	RollonRolloff_cabDupla(161),

	RollonRolloff_cabEstendida(162),

	RollonRolloff_cabSuplementar(163),

	basculante_cabDupla(164),

	basculante_cabEstendida(165),

	Basculante_cabSuplementar(166),

	prancha_cabDupla(167),

	prancha_cabEstendida(168),

	prancha_cabSuplementar(169),

	prancha_mecOperac_cabDupla(170),

	prancha_mecOperac_cabEstendida(171),

	prancha_mecOperacional_cabSuplementar(172),

	carrocAber_Intercambiavel_cabDupla(173),

	carrocAber_Intercambiavel_cabEstendida(174),

	carrocAber_Intercambiavel_cabSuplementar(175),

	carrocAber_cabTripla(176),

	carrocFech_cabTripla(177),

	comercio(178),

	transpGranito(179),

	silo_basculante(180),

	basc_mecOperac(181),

	chassiConteiner_cabEstendida(182),

	mecOperac_cabEstendida(183),

	silo_cabEstendida(184),

	container_carrocAber_cabEstendida(185),

	pranchaConteiner_cabEstendida(186),

	transpToras_cabEstendida(187),

	silo_basculante_cabEstendida(188),

	som(189),

	transporteEscolar(190),

	trasnporteValores(191),

	transporteValores_mercadoriaOperacional(192),

	tanqueProdutoPerigoso(193),

	inacabada(194),

	transpGranito_cabEstendida(195),

	basculante_mecanismoOperac_cabEstendida(196),

	chassiConteiner_cabDupla(197),

	silo_cabDupla(198),

	container_carrocAber_cabDupla(199),

	PranchaConteiner_cabDupla(200),

	transpToras_cabDupla(201),

	transpGranito_cabDupla(202),

	silo_basculante_cabDupla(203),

	basculante_mecanismoOperac_cabDupla(204),

	cabSuplementar(205),

	chassiConteiner_cabSuplementar(206),

	mecOperac_cabSuplementar(207),

	silo_cabSuplementar(208),

	container_carrocAber_cabSuplementar(209),

	pranchaConteiner_cabSuplementar(210),

	transpToras_cabSuplementar(211),

	transpGranito_cabSuplementar(212),

	silo_basculante_cabSuplementar(213),

	basculante_mecanismoOperac_cabSuplementar(214),

	inacabada_cabSuplementar(215),

	cabLinear(216),

	carrocAberta_cabLinear(218),

	carrocFechada_cabLinear(219),

	chassiConteiner_cabLinear(220),

	MecOperacional_cabLinear(221),

	prancha_cabLinear(222),

	silo_cabLinear(223),

	tanque_cabLinear(224),

	Conteiner_carrocAber_cabLinear(225),

	pranchaConteiner_cabLinear(226),

	RollonRolloff_cabLinear(227),

	transpToras_cabLinear(228),

	aberta_Intercambiavel_cabLinear(229),

	carrocAber_mecOperacional_cabLinear(230),

	CarrocFech_mecOperac_cabLinear(231),

	Tanque_MecOperac_CabLinear(232),

	cabLinear_prancha_mecOperac(233),

	transpGranito_cabineLinear(234),

	silo_basculante_cabLinear(235),

	basculante_mecanismoOperac_linear(236),

	Inacabada_cabLinear(237),

	cabTripla(238),

	mecOperac_cabTripla(239),

	inacabada_cabineTripla(240),

	tanqueProdutoPerigoso_cabEstendida(241),

	tanqueProdutoPerigoso_cabDupla(242),

	tanqueProdutoPerigoso_cabSuplementar(243),

	tanqueProdutoPerigoso_cabLinear(244),

	nenhuma(9999);

	public int valorCarroceria;

    private TipoCarroceria(int valorCarroceria) {
        this.valorCarroceria = valorCarroceria;
    }

	  

}
