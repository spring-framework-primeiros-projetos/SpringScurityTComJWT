package Mudar.backend.Atores.entity;


import Mudar.backend.Emolumento.entity.Saldo;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * A Classe Saldotransportador é o detentor da relação do transportador com o seu saldo de serviços acumulados para pagamento do transportador.
 * @author Alvaro
 */
@Entity
@Table(name="SALDO_TRANSPORTADOR")
@IdClass(SaldoTransportador.class)
@SuppressWarnings("PersistenceUnitPresent")
public class SaldoTransportador implements Serializable{
    
    /**
     * O atributo idtrans é o identificador o transportador para relacionar os destinatário do pagamento que deve ser feito.
     */
    @Id
    @JoinColumn(name="ID_TRANS",unique = true, nullable = true )
    @OneToOne()
    private Transportador idtrans;
    
    /**
     * O atributo idSal é o identificador do saldo do transportador para verificar o valor do transportador para pagar.
     */
    @Id
    @JoinColumn(name="ID_SALDO", unique = true, nullable = true,insertable = false )
    @OneToOne()
    private Saldo idSal;

    /**
     * construtor vazio não utilizar
     */
    public SaldoTransportador() {
    }
    
    /**
     * O construtor gera um novo registro de saldo e transportador.
     * @param idtrans
     * @param idSal 
     */
    public SaldoTransportador(Transportador idtrans, Saldo idSal) {
        this.idtrans = idtrans;
        this.idSal = idSal;
    }

    /**
     * O método retorna o ID do transportador.
     * @return  ID transportador.
     */
    public Transportador getIdtrans() {
        return idtrans;
    }

    /**
     * O método determina o ID do transportador.
     * @param idtrans 
     */
    public void setIdtrans(Transportador idtrans) {
        this.idtrans = idtrans;
    }

    /**
     * O método retorna o ID do saldo.
     * @return  ID do saldo.
     */
    public Saldo getIdSal() {
        return idSal;
    }

    /**
     * O método determina o ID do saldo.
     * @param idSal 
     */
    public void setIdSal(Saldo idSal) {
        this.idSal = idSal;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.idtrans);
        hash = 29 * hash + Objects.hashCode(this.idSal);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SaldoTransportador other = (SaldoTransportador) obj;
        if (!Objects.equals(this.idtrans, other.idtrans)) {
            return false;
        }
        if (!Objects.equals(this.idSal, other.idSal)) {
            return false;
        }
        return true;
    }
    
    
}


