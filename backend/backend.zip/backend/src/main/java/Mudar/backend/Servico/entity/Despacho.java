package Mudar.backend.Servico.entity;

import Mudar.backend.Emolumento.entity.Proventos;
import Mudar.backend.Endereco.DestinoEndereco;
import Mudar.backend.Endereco.OrigemEndereco;
import Mudar.backend.Enumeradores.Pagamento;
import Mudar.backend.Enumeradores.Servico;
import Mudar.backend.Frete.entity.ConstrutorFretes;
import Mudar.backend.Tranporte.entity.VeiculoTransportador;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * Classe genérica abstrata para determinar um padrão para construção de solicitações de serviço para o sistema. 
 */
@Entity
@Table(name="DESPACHO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public abstract class Despacho implements Serializable {

    /**
     * A variável local ID será o identificador da solicitação correspondente a Classe.
     */
    @Id
    @NotNull(message = "ID não pode estar vazio.")
    @Column(name="ID_DESPACHO", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID id;

    /**
     * A variável local enderecoOrigem alocará o endereço no qual o ator transportador deve estar para carregar o veículo com os itens que serão transportados.
     */
    @NotNull(message = "Endereço de origem não pode estar vazio.")
    @Column(name="ENDERECO_ORIGEM")
    @Embedded
    private OrigemEndereco EnderecoOrigem;

    /**
     * A variável local enderecoDestino alocará o endereço no qual o ator transportador deve estar para descarregar o veículo com os itens que foram tranportados.
     */
    @NotNull(message = "Endereço  de destino não pode estar vazio.")
    @Column(name="ENDERECO_DESTINO")
    @Embedded
    private DestinoEndereco EnderecoDestino;

    /**
     *  A variável local frete alocará o identificador do orçamento efetuado para o serviço solicitado.
     */
    @NotNull(message = "Endereço não pode estar vazio.")
    @JoinColumn(name="ID_FRETE")
    @ManyToOne
    private ConstrutorFretes frete;

    /**
     * A variável statusServico alocará em qual status se encontra o serviço solicitado pelo ator Solicitante.
     */
    @NotNull(message = "Status do serviço não pode estar vazio.")
    @Column(name="STATUS_SERVIÇO")
    @Enumerated(EnumType.STRING)
    private Servico statusServico;

    /**
     * A variável local statusPagamento alocará o status atual do pagamento do serviço solicitado.
     */
    @NotNull(message = "Status do pagamento não pode estar vazio.")
    @Column(name="STATUS_PAGAMENTO")
    @Enumerated(EnumType.STRING)
    private Pagamento statusPagamento;

    /**
     * A variável Atendimento alocará a data e hora que o serviço deve ser prestado ao cliente.
     */
    @NotNull(message = "Status do pagamento não pode estar vazio.")
    @Column(name="SOLICITATO_EM")
    @Temporal(TemporalType.DATE)
    private Date Atendimento;

    /**
     * A variável distancia alocará a distância  total e exata entre o endereçoOrigem e enderecoDestino.
     */
    @NotNull(message = "Status do pagamento não pode estar vazio.")
    @Column(name="DISTANCIA")
    private float Distancia;

    @JoinColumn(name="TRANSPORTADOR_VEICULO")
    @ManyToOne
    private VeiculoTransportador Transportador;
    /**
     * A variável local total alocará o total de custo do serviço solicitado pelo ator Solicitante.
     */
    @JoinColumn(name="ORCAMENTO")
    @ManyToOne
    private Proventos Orcamento;

    /**
     * O método CalculaTotal executará o cálculo de todos os valores e alocará no total
     * @return 
     */
    public abstract float CalculaTotal();

    /**
     * Construtor vazio, não utilizar.
     */
    public Despacho() {
    }
    
    /**
     * O Construtor da classe despacho e poderá ser usada como super em seus descendentes
     * 
     * @param id
     * @param EnderecoOrigem
     * @param EnderecoDestino
     * @param frete
     * @param statusServico
     * @param statusPagamento
     * @param Atendimento
     * @param Distancia
     * @param Transportador
     * @param Orcamento 
     */
    public Despacho(UUID id, OrigemEndereco EnderecoOrigem, DestinoEndereco EnderecoDestino, ConstrutorFretes frete, Servico statusServico, Pagamento statusPagamento, Date Atendimento, float Distancia, VeiculoTransportador Transportador, Proventos Orcamento) {
        this.id = id;
        this.EnderecoOrigem = EnderecoOrigem;
        this.EnderecoDestino = EnderecoDestino;
        this.frete = frete;
        this.statusServico = statusServico;
        this.statusPagamento = statusPagamento;
        this.Atendimento = Atendimento;
        this.Distancia = Distancia;
        this.Transportador = Transportador;
        this.Orcamento = Orcamento;
    }

    /**
     * O método retorna o ID solicitado.
     * @return 
     */
    public UUID getId() {
        return id;
    }

    /**
     * O método determina o ID do despacho.
     * @param id 
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * O método determina o endereço de origem.
     * @return 
     */
    public OrigemEndereco getEnderecoOrigem() {
        return EnderecoOrigem;
    }

    /**
     * O método determina o endereço de destino.
     * @param EnderecoOrigem 
     */
    public void setEnderecoOrigem(OrigemEndereco EnderecoOrigem) {
        this.EnderecoOrigem = EnderecoOrigem;
    }

    /**
     * O método retorna o endereço de destino.
     * @return 
     */
    public DestinoEndereco getEnderecoDestino() {
        return EnderecoDestino;
    }

    /**
     * O método determina o endereço de destino.
     * @param EnderecoDestino 
     */
    public void setEnderecoDestino(DestinoEndereco EnderecoDestino) {
        this.EnderecoDestino = EnderecoDestino;
    }

    /**
     * O método retorna o frete do serviço.
     * @return 
     */
    public ConstrutorFretes getFrete() {
        return frete;
    }

    /**
     * O método determina o frete do serviço.
     * @param frete 
     */
    public void setFrete(ConstrutorFretes frete) {
        this.frete = frete;
    }

    /**
     * O método retorna o status do serviço
     * @return 
     */
    public Servico getStatusServico() {
        return statusServico;
    }

    /**
     * O método determina o status do serviço.
     * @param statusServico 
     */
    public void setStatusServico(Servico statusServico) {
        this.statusServico = statusServico;
    }

    /**
     * O método retorna o status do pagamento.
     * @return 
     */
    public Pagamento getStatusPagamento() {
        return statusPagamento;
    }

    /**
     * O método determina o status do pgamento.
     * @param statusPagamento 
     */
    public void setStatusPagamento(Pagamento statusPagamento) {
        this.statusPagamento = statusPagamento;
    }

    /**
     * O método retorna data do atendimento.
     * @return 
     */
    public Date getAtendimento() {
        return Atendimento;
    }

    /**
     * O método determina a data de atendimento.
     * @param Atendimento 
     */
    public void setAtendimento(Date Atendimento) {
        this.Atendimento = Atendimento;
    }

    /**
     * O método retorna a distância do trajeto.
     * @return 
     */
    public float getDistancia() {
        return Distancia;
    }

    /**
     * O método determina a distância do trajeto.
     * @param Distancia 
     */
    public void setDistancia(float Distancia) {
        this.Distancia = Distancia;
    }

    /**
     * O método retorna o ID do Veículo Transportador.
     * @return 
     */
    public VeiculoTransportador getTransportador() {
        return Transportador;
    }

    /**
     * O método determina o ID do Veículo transportador.
     * @param Transportador 
     */
    public void setTransportador(VeiculoTransportador Transportador) {
        this.Transportador = Transportador;
    }

    /**
     * O método retorna o Orçamento do transporte.
     * @return 
     */
    public Proventos getOrcamento() {
        return Orcamento;
    }

    /**
     * O método retorna o Orçamento do Transporte.
     * @param Orcamento 
     */
    public void setOrcamento(Proventos Orcamento) {
        this.Orcamento = Orcamento;
    }
    
    

}















