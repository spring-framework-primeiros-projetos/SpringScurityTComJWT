package Mudar.backend.Tranporte.entity;

import Mudar.backend.Atores.entity.Transportador;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * A Classe Ternária  Veículo transportador busca efetuar a relação entre o transportador e o veículo que ele cadastrou.
 * @author alvaro
 */

@Entity
@Table(name="VEICULOTRANSPORTADOR")
public class VeiculoTransportador implements Serializable{
    
    /**
     * A variável ID alocará a identificação sistêmica do Usuário e seus descendentes.
     */
    @Id
    @Column(name="ID_USUARIO", unique = true, nullable = true,insertable = false)
    private byte[] id;
    
    /**
     * O Atributo busca determinar o ID do Caminhão(parte motorizada do veículo.
     */
    
    @JoinColumn(name="ID_CAMINHAO", nullable = false )
    @OneToOne()
    public Caminhao idplaca;
    
    /**
     * O atributo Busca determinar O ID da Carroceria(parte de armazenamento de produtos que serão transportados.
     */
    
    @JoinColumn(name="ID_CARROCERIA", nullable = false )
    @OneToOne()
    public Carroceira idcarroceria;

    /**
     * O atributo busca determinar o ID do transportador dono do veículo como um todo.
     */
    @JoinColumn(name="idtrans", nullable = false )
    @OneToOne()
    public Transportador idtrans;
    
    /** 
     * Construtor vazio
     * NÃO UTILIZAR.    
     */
    public VeiculoTransportador() {
    }
    
    /**
     *  O construtor busca fazer o relacionamento do transportador, caminhão e carroceria.
     * @param idplaca
     * @param idcarroceria
     * @param idtransportador 
     */
    public VeiculoTransportador(Caminhao idplaca, Carroceira idcarroceria, Transportador idtransportador) {
        this.idplaca = idplaca;
        this.idcarroceria = idcarroceria;
        this.idtrans = idtransportador;
    }

    /**
     * O método retorna o ID do caminhão
     * @return 
     */
    public Caminhao getIdplaca() {
        return idplaca;
    }

    /**
     * O método determina o ID do caminhão
     * @param idplaca 
     */
    public void setIdplaca(Caminhao idplaca) {
        this.idplaca = idplaca;
    }

    /**
     * O método retorna o ID da carroceria.
     * @return 
     */
    public Carroceira getIdcarroceria() {
        return idcarroceria;
    }

    /**
     * O método determina o ID da carroceria.
     * @param idcarroceria 
     */
    public void setIdcarroceria(Carroceira idcarroceria) {
        this.idcarroceria = idcarroceria;
    }

    /**
     * O método retorna o transportador do veículo.
     * @return 
     */
    public Transportador getIdtrans() {
        return idtrans;
    }

    /**
     * O método determina o transportador do veículo.
     * @param idtrans 
     */
    public void setIdtrans(Transportador idtrans) {
        this.idtrans = idtrans;
    }

    

}





