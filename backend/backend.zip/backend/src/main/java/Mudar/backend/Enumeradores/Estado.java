package Mudar.backend.Enumeradores;

/**
 * O enumerador Estado alocará todos os estados brasileiros assumindo como número identificador o DDD da capital
 * @author Alvaro
 */
public enum Estado {
    
    /**
     * Identifcador do Estado do Acre (AC) - Rio Branco
     */
    AC(68),

    /**
     * Identifcador do Estado de Alagoas (AL) - Maceió
     */
    AL(82),

    /**
     * Identifcador do Estado do Amapá (AP) - Macapá
     */
    AP(96),

    /**
     * Identifcador do Estado do Amazonas (AM) - Manaus
     */
    AM(92),

    /**
     * Identifcador do Estado da Bahia (BA) - Salvador
     */
    BA(71),

    /**
     * Identifcador do Estado do Ceará (CE) - Fortaleza
     */
    CE(88),

    /**
     * Identifcador do Estado do Distrito Federal (DF) - Brasília
     */
    DF(61),

    /**
     * Identifcador do Estado do Espírito Santo (ES) - Vitória
     */
    ES(27),

    /**
     * Identifcador do Estado de Goiás (GO) - Goiânia
     */
    GO(62),

    /**
     * Identifcador do Estado do Maranhão (MA) - São Luís
     */
    MA(98),

    /**
     * Identifcador do Estado do Mato Grosso (MT) - Cuiabá
     */
    MT(65),

    /**
     * Identifcador do Estado do Mato Grosso do Sul (MS) - Campo Grande
     */
    MS(84),

    /**
     * Identifcador do Estado de Minas Gerais (MG) - Belo Horizonte
     */
    MG(31),

    /**
     * Identifcador do Estado do Pará (PA) - Belém
     */
    PA(91),
    

    /**
     * Identifcador do Estado da Paraíba (PB) - João Pessoa
     */
    PB(83),
    
    /**
     * Identifcador do Estado do Paraná (PR) - Curitiba
     */
    PR(41),

    /**
     * Identifcador do Estado de Pernambuco (PE) - Recife
     */
    PE(81),

    /**
     * Identifcador do Estado do Piauí (PI) - Teresina
     */
    PI(86),

    /**
     * Identifcador do Estado do Rio de Janeiro (RJ) - Rio de Janeiro
     */
    RJ(21),

    /**
     * Identifcador do Estado do Rio Grande do Norte (RN) - Natal
     */
    RN(84),

    /**
     * Identifcador do Estado do Rio Grande do Sul (RS) - Porto Alegre
     */
    RS(51),

    /**
     * Identifcador do Estado de Rondônia (RO) - Porto Velho
     */
    RO(69),

    /**
     * Identifcador do Estado de Roraima (RR) - Boa Vista
     */
    RR(95),

    /**
     * Identifcador do Estado de Santa Catarina (SC) - Florianópolis
     */
    SC(48),

    /**
     * Identifcador do Estado de São Paulo (SP) - São Paulo
     */
    SP(11),
    
    /**
     * Identifcador do Estado de Sergipe (SE) - Aracaju
     */
    SE(79),


    /**
     * Identifcador do Estado de Tocantins (TO) – Palmas
     */
    TO(63);

    public int valorEstado;

    /**
     *  Construtor para a classe Estado.
     */
    private Estado(int valorEstado) {
        this.valorEstado = valorEstado;
    }

	
	

}
