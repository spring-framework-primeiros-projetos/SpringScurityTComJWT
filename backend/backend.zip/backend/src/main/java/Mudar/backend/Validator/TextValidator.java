/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Validator;

/**
 *
 * @author Alvaro
 */
public class TextValidator {
    public boolean matchesOnlyText(String text) {
    return text.matches("[A-Z_a-z_À-ú\\s\\p{L}]+");
    }
    /**
     *
     * @param str
     * @return  primeira letra de cada palavra com em maiúscula exceto para sílabas
     */
    public static String toTitledCase(String str){

    String[] words = str.split(" ");
    StringBuilder sb = new StringBuilder();
  
    for(int i = 0; i < words.length; i++){
        String[] word= words[i].split("\\s");
        if (words[i].length() > 2){
            for (int y = 0;y<word.length;y++){
            sb.append(word[y].substring(0, 1).toUpperCase() + word[y].substring(1).toLowerCase());
            sb.append(" ");  
            }
        } else {
            sb.append(words[i].toLowerCase());
            sb.append(" ");        
        }
    }

    return sb.toString().substring (0, sb.length() - 1);
    }
    
    public static String toTitledCase2(String str){

    String[] words = str.split("_");
    StringBuilder sb = new StringBuilder();
  
    for(int i = 0; i < words.length; i++){
        String[] word= words[i].split("\\s");
        if (words[i].length() > 2){
            for (int y = 0;y<word.length;y++){
            sb.append(word[y].substring(0, 1).toUpperCase() + word[y].substring(1).toLowerCase());
            sb.append(" ");  
            }
        } else {
            sb.append(words[i].toLowerCase());
            sb.append(" ");        
        }
    }

    return sb.toString().substring (0, sb.length() - 1);
    }
    /**
     * Gera nome de usuário padronizado para o sistema.
     * @param nome
     * @return 
     */
    public String GeraUsuario(String nome){
        String[] words = nome.split(" ");
        return words[0] +"."+ words[words.length-1];
        
    }
    /**
     * Converte valor real de vírgula para ponto.
     * @param valor
     * @return 
     */
    public double ConverteVirgula(String valor){
        String replace = valor.replace(",",".");
        try{
            return Double.parseDouble(replace);
        }catch(NumberFormatException e){
            return 0.0 ;
        }
        
        
    }
    public String ConvertePonto(double valor){
        String replace = Double.toString(valor);
         return replace = replace.replace(".",",");
    }
    
}
