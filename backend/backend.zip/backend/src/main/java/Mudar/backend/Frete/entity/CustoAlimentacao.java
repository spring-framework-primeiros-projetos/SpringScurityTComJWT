package Mudar.backend.Frete.entity;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A classe especializada CustoAlimentação determina o valor há ser pago no total para o ator Transportador pelo transporte do produto
 * em viagens que levarão mais de um dia de transporte.
 */
@Entity
@Table(name="ORCAMENTO")
public class CustoAlimentacao extends Custo {
    /**
     * A variável valorAlimetacao aloca Total gasto no transporte do produto para alimentação do transportador.
     */
    @NotNull(message = "Nome não pode estar vazio.")
    @Column( name = "VALOR_ALIMENTACAO")
    private float valorAlimetacao;

    /**
     * Construtor vazio não utilizar.
     */
    public CustoAlimentacao() {
    }

    /**
     * o Construtor para armazenamento total de custos com alimentos.
     * @param id
     * @param valorAlimetacao 
     */
    public CustoAlimentacao(UUID id,float valorAlimetacao) {    
        super(id);
        this.valorAlimetacao = valorAlimetacao;
    }

    /**
     * O método busca retornar o  custo da alimentação.
     * @return 
     */
    public float getValorAlimetacao() {
        return valorAlimetacao;
    }

    /**
     * O valor determina o custo da alimentação.
     * @param valorAlimetacao 
     */
    public void setValorAlimetacao(float valorAlimetacao) {
        this.valorAlimetacao = valorAlimetacao;
    }
    
    

    

}
