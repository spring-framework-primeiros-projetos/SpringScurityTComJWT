package Mudar.backend.Frete.entity;


import Mudar.backend.Enumeradores.tipoCarga;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

/**
 * A classe especializada CustoCarga busca estimar o valor do frete básico do ator Transportador ao executar o serviço do cliente.
 */
@Entity
@Table(name="ORCAMENTO")
public class CustoCarga extends Custo {
    /**
     * A variável tipoCarga alocará a informação do tipo da carga para estipular os custos
     */
    @NotNull(message = "Nome não pode estar vazio.")
    @Column(name = "TIPO_CARGA", length = 2)
    @Enumerated(EnumType.ORDINAL)
    private tipoCarga tipoCarga;

    /**
     * A variável distancia alocará a distancia no transporte da carga
     */
    @Length( max = 20, message = "A distância deve conter o máximo de 20 caracteres.")
    @NotNull(message = "A distância não pode estar vazio.")
    @Column(name = "DISTANCIA",length = 20)
    private float distancia;

    /**
     * A variável eixo alocará o total de eixos que o veículo possui para o cálculo do frete.
     */
    @Column(name = "EIXO",length = 2)
    private int eixo;

    /**
     * A variável cargaDescarga alocará um taxa de carga e descarga de itens da carga no tempo de espera do cliente.
     */
    @Length( max = 20, message = "O custo da carga e descarga deve conter o máximo de 20 caracteres.")
    @NotNull(message = "Carga e descarga não pode estar vazio.")
    @Column(name = "CARGA_DESCARGA",length = 20)
    private float cargaDescarga;

    /**
     * A variável total carga alocará o custo total para transporte de carga.
     */
    @Length( max = 20, message = "O toal do custo da carga deve conter o máximo de 20 caracteres.")
    @NotNull(message = "OCusto total não pode estar vazio.")
    @Column(name = "Total_Custo_Carga",length = 20)
    private float totalCarga;

    /**
     * Construtor vazio não utilizar
     */
    public CustoCarga() {
    }

    public CustoCarga(tipoCarga tipoCarga, float distancia, int eixo, float cargaDescarga, float totalCarga) {
        this.tipoCarga = tipoCarga;
        this.distancia = distancia;
        this.eixo = eixo;
        this.cargaDescarga = cargaDescarga;
        this.totalCarga = totalCarga;
    }

    /**
     * Construtor gerado para inicializar o custo de carga para cada orçamento.
     * @param tipoCarga
     * @param distancia
     * @param eixo
     * @param cargaDescarga
     * @param totalCarga
     * @param id
     */
    public CustoCarga(UUID id,tipoCarga tipoCarga, float distancia, int eixo, float cargaDescarga, float totalCarga) {
        super(id);
        this.tipoCarga = tipoCarga;
        this.distancia = distancia;
        this.eixo = eixo;
        this.cargaDescarga = cargaDescarga;
        this.totalCarga = totalCarga;
    }

    /**
     * O método retorna o tipo da carga.
     * @return 
     */
    public tipoCarga getTipoCarga() {
        return tipoCarga;
    }

    /**
     * O método determina o tipo da carga.
     * @param tipoCarga 
     */
    public void setTipoCarga(tipoCarga tipoCarga) {
        this.tipoCarga = tipoCarga;
    }

    /**
     * O método retorna a distância que o veículo terá no transporte.
     * @return 
     */
    public float getDistancia() {
        return distancia;
    }

    /**
     * O método determina a distância que o veículo terá no transporte.
     * @param distancia 
     */
    public void setDistancia(float distancia) {
        this.distancia = distancia;
    }

    /**
     * O método retorna o eixo do veículo.
     * @return 
     */
    public int getEixo() {
        return eixo;
    }

    /**
     * O método determina o eixo do veículo.
     * @param eixo 
     */
    public void setEixo(int eixo) {
        this.eixo = eixo;
    }

    /**
     * O método retorna o Custo para carga e descarga.
     * @return 
     */
    public float getCargaDescarga() {
        return cargaDescarga;
    }

    /**
     * O método determina o custo da carga e descarga.
     * @param cargaDescarga 
     */
    public void setCargaDescarga(float cargaDescarga) {
        this.cargaDescarga = cargaDescarga;
    }

    /**
     * O método retorna o custo total para transporte de carga.
     * @return 
     */
    public float getTotalCarga() {
        return totalCarga;
    }

    /**
     * O método determina o custo total para transporte de carga.
     * @param totalCarga 
     */
    public void setTotalCarga(float totalCarga) {
        this.totalCarga = totalCarga;
    }
    
    
        

}
