package Mudar.backend.Servico.entity;

/**
 * A classe especializada GeraServicoFinal busca gerar o serviço de entrega dos itens solicitados ao cliente.
 */
public class GeraEntrega{

	

}















