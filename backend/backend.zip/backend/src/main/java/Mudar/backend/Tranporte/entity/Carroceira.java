package Mudar.backend.Tranporte.entity;


import Mudar.backend.Enumeradores.Categoria;
import Mudar.backend.Enumeradores.TipoCarroceria;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

/**
 * A classe Carroceira Visa saber as medidas e volume cúbico do para transporte do itens solicitados para transporte.
 * @author Alvaro
 * @
 */
@Entity
@Table(name="CARROCERIA")
public class Carroceira implements Serializable {
    
    /**
     * A variável ID alocará o identificador da carroceria.
     */
    @Id
    @NotNull(message = "ID não pode esta vazio.")
    @Column(name="ID_USUARIO", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID Id;
    
    /**
     * A variável Comprimento alocará o comprimento da carroceria do veículo.
     */
    @Column(name = "COMPRIMENTO",length = 20, nullable = false)
    @Length( max = 20, message = "O comprimento máximo somente pode ser de 20 dígitos.")
    @NotNull(message = "Comprimento não pode ser vazio.")
    private double comprimento;
    
    /**
     * A variável largura alocará a largura da carroceria.
     */
    @Column(name = "LARGURA",length = 20, nullable = false)
    @Length( max = 20, message = "A largura máximo somente pode ser de 20 dígitos.")
    @NotNull(message = "Largura não pode ser vazia.")
    private double largura;

    /**
     * A variável altura alocará a altura da carroceria
     */
    @Column(name = "ALTURA",length = 20, nullable = false)
    @Length( max = 20, message = "A Altura máximo somente pode ser de 20 dígitos.")
    @NotNull(message = "Altura não pode ser vazia.")
    private double altura;

    /**
     * A variável categoria alocará a categoria da carroceria.
     */
    @Column(name = "CATEGORIA")
    @Enumerated(EnumType.STRING)
    @NotNull(message = "A categoria não pode estar vazia.")
    private Categoria categoria;
    
    /**
     * A variável categoria alocará a categoria da carroceria.
     */
    @Column(name = "CARROCERIA",length = 4)
    @Enumerated(EnumType.ORDINAL)
    @NotNull(message = "O tipo de carroceria não pode estar vazio.")
    private TipoCarroceria tipoCarroceria;

    /** 
     * A variável volume alocará o volume do veículo.
     */
    @Column(name = "VOLUME",length = 30)
    private double volume;
    
    /**
     * construtor vazio 
     * NÃO UTILIZAR!
     */
    public Carroceira() {
    }

    /**
     *  Construtor de veículo para registro no banco.
     * @param Id
     * @param comprimento
     * @param largura
     * @param altura
     * @param categoria
     * @param tipoCarroceria 
     */
    public Carroceira(UUID Id, double comprimento, double largura, double altura, Categoria categoria, TipoCarroceria tipoCarroceria) {
        this.Id = Id;
        this.comprimento = comprimento;
        this.largura = largura;
        this.altura = altura;
        this.categoria = categoria;
        this.tipoCarroceria = tipoCarroceria;
        this.volume = comprimento*largura*altura;
    }

    /**
     * O método retorna o ID da Carroceria.
     * @return 
     */
    public UUID getId() {
        return Id;
    }

    /**
     * O método determina o ID da carroceria.
     * @param Id 
     */
    public void setId(UUID Id) {
        this.Id = Id;
    }

    /**
     * O método retorna o comprimento da carroceria.
     * @return 
     */
    public double getComprimento() {
        return comprimento;
    }

    /**
     * O método determina o comprimento da carroceira.
     * @param comprimento 
     */
    public void setComprimento(double comprimento) {
        this.comprimento = comprimento;
    }

    /**
     * O método retorna a largura da carroceria.
     * @return 
     */
    public double getLargura() {
        return largura;
    }

    /**
     * O método determina a largura da carroceria.
     * @param largura 
     */
    public void setLargura(double largura) {
        this.largura = largura;
    }

    /** 
     * o método determina a largura da carroceria.
     * @return 
     */
    public double getAltura() {
        return altura;
    }

    /**
     * O método determina a altura da carroceria.
     * @param altura 
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * O método retorna a categoria da carroceria.
     * @return 
     */
    public Categoria getCategoria() {
        return categoria;
    }

    /**
     * O método determina a categoria da carroceria.
     * @param categoria 
     */
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    /**
     * O método retorna o tipo da carroceria.
     * @return 
     */
    public TipoCarroceria getTipoCarroceria() {
        return tipoCarroceria;
    }

    /**
     *  O método determina o tipo da Carroceria.
     * @param tipoCarroceria 
     */
    public void setTipoCarroceria(TipoCarroceria tipoCarroceria) {
        this.tipoCarroceria = tipoCarroceria;
    }

    /**
     *  o método retorna o volume da carroceria.
     * @return 
     */
    public double getVolume() {
        return volume;
    }

    /**
     * O método determina o volume da carroceria.
     * @param volume 
     */
    public void setVolume(double volume) {
        this.volume = volume;
    }
    
    
    
    
    

}
