package Mudar.backend.Frete.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A classe genérica e abstrata Custo busca ser um auxiliador a especialização dos valores a serem pagos no sistema.
 */
@Entity
@Table(name="ORCAMENTO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public abstract class Custo implements Serializable{
    
    /**
     * A variável determina o ID do orçamento do produto que será gerado pelo orçamento
     */
    @Id
    @NotNull(message = "ID não pode esta vazio.")
    @Column(name="ID_servico", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID id;

    /**
     * Não utilizar o construtor vazio.
     */
    public Custo() {
    }

    /**
     * O construtor determina o ID dos custos e seus  descendentes.
     * @param id 
     */
    public Custo(UUID id) {
        this.id = id;
    }

    /**
     * O método retorna o ID do orçamento.
     * @return 
     */
    public UUID getId() {
        return id;
    }

    /**
     * O método determina o ID do orçamento.
     * @param id 
     */
    public void setId(UUID id) {
        this.id = id;
    }
    
    
	
}
