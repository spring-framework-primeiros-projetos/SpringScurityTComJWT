package Mudar.backend.Enumeradores;

/**
 *  A Classe enumeradora Carteira gere o tipo de carteira do ator Transportador possui no sistema..
 */
public enum Carteira {

    /**
     * O enumerador A esta designado para condutor de veículo motorizado de 2 ou 3 rodas, como motos ou triciclos.
     */
    A(1),

    /**
     * O enumerador B esta designado para condutor de veículo motorizado cujo peso total não deve exceder 3500 Kg, com lotação máxima de 8 ocupantes. Ex: carros de passeio.
     */
    B(2),

    /**
     * O enumerador C esta designado para condutor de veículo motorizado utilizado para transporte de carga, com o peso bruto para além de 3500 Kg.
     * Para  essa categoria o motorista deve estar a pelo menos um ano com a CNH da Categoria B.
     */
    C(3),

    /**
     * O enumerador D esta designado que  a partir desta categoria não há mais limite de passageiros.
     * Liberando pra dirigir ônibus por exemplo, onde se excede os 8 passageiros que tínhamos desde a categoria B.
     * As outras restrições são iguais a categoria C.
     */
    D(4),

    /**
     * O enumerador E é a mais alta categoria que temos na legislação brasileira, não tem restrições.
     * Tanto de passageiros (como já se tinha na D), como de carga (como já se tinha desde a C).
     * Mas agora também não há mais o limite de peso bruto total também do reboque, que o veículo pode puxar, podendo, inclusive ser mais de um reboque, sem problemas.
     */
    E(5);

    public int valorCarteira;


    private Carteira(int valorCarteira) {
        this.valorCarteira = valorCarteira;
    }
        

}
