package Mudar.backend.Enumeradores;

/**
 * A Classe enumeradora combustível busca determinar o tipo utilizado para locomoção do veículo.
 * @author Alvaro
 */
public enum Combustivel {
    Gasolina_comum,
    Gasolina_aditivada,
    Gasolina_premium,
    Gasolina_formulada, 
    Etanol,
    Etanol_aditivado,
    Gás_Natural_Veicular,
    Diesel,
    Diesel_S10,
    Diesel_aditivado,
    Diesel_Premium,
    Gas_veicular, 
    Bio_diesel;
}
