package Mudar.backend.Emolumento.entity;

import Mudar.backend.Atores.entity.Transportador;
import Mudar.backend.Atores.entity.Usuario;
import Mudar.backend.Enumeradores.Pagamento;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Alvaro
 */
@Entity
@Table(name="EMOLUMENTO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
public abstract class Proventos implements Serializable {

    /**
     * A variável ID alocará a identificação sistêmica do Usuário e seus descendentes.
     */
    @NotNull(message = "ID não pode estar vazio.")
    @Column(name="ID_USUARIO", unique = true, nullable = true,insertable = false)
    @Id
    private UUID id;
    
    /**
     * A variável gerado alocará a data em que o processo foi solicitado no sistema.
     */
    @Column(name = "GERADO")
    @Temporal(TemporalType.DATE)
    private Date gerado;

    /**
     * A variável pago alocará a data em que o processo foi constou pagamento no sistema.
     */
    @Column(name = "PAGO")
    @Temporal(TemporalType.DATE)
    private Date pago;

    /**
     * A variável status alocará o status de pagamento.
     */
    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private Pagamento status;

    /**
     *  A variável local valor alocará o valor total no qual o pagamento deve ser gerado.
     */
    @JoinColumn(name = "VALOR")
    @OneToOne
    private Valores valor;
    /**
     * A variável local pagante alocará o ID do usuário que efetuará o pagamento.
     */
    @JoinColumn(name = "PAGANTE")
    @OneToOne
    private Usuario pagante;

    /**
     * A variável local destinatário alocará o usuário no qual se destinará o 
     * pagamento, efetuado após o recolhimento do percentual de lucro.
     */
    @JoinColumn(name = "TRANSPORTADOR")
    @OneToOne
    private Transportador destinatario;

    /**
     * O método GeraPagamento instanciará um novo método de pagamento de acordo com o orçamento informado.
     * @return 
     */
    public abstract GeraPagamento pagamento();

    /**
     * Construtor vazio, não utilizar.
     */
    public Proventos() {
    }
    
    /**
     * O construtor da classe do Proventos e poderá ser usada como super em seus descendentes.
     * @param id
     * @param gerado
     * @param pago
     * @param status
     * @param valor
     * @param pagante
     * @param destinatario 
     */
    public Proventos(UUID id, Date gerado, Date pago, Pagamento status, Valores valor, Usuario pagante, Transportador destinatario) {
        this.id = id;
        this.gerado = gerado;
        this.pago = pago;
        this.status = status;
        this.valor = valor;
        this.pagante = pagante;
        this.destinatario = destinatario;
    }

    /**
     * O método retorna o ID da classe.
     * @return 
     */
    public UUID getId() {
        return id;
    }

    /**
     * O método determina o ID da classe.
     * @param id 
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * O método retorna a data de solicitação do serviço.
     * @return 
     */
    public Date getGerado() {
        return gerado;
    }

    /**
     * O método determina a data de solicitação do serviço.
     * @param gerado 
     */
    public void setGerado(Date gerado) {
        this.gerado = gerado;
    }

    /**
     * O método retorna a data em que o serviço foi pago.
     * @return 
     */
    public Date getPago() {
        return pago;
    }

    /**
     * O método determina a data que o serviço foi pago.
     * @param pago 
     */
    public void setPago(Date pago) {
        this.pago = pago;
    }

    /**
     * O método determina o status em que o pagamento sem encontra.
     * @return 
     */
    public Pagamento getStatus() {
        return status;
    }
    
    /**
     * O método determina o Status em que o serviço se encontra.
     * @param status 
     */
    public void setStatus(Pagamento status) {
        this.status = status;
    }

    /**
     * O método retorna o valor do serviço.
     * @return 
     */
    public Valores getValor() {
        return valor;
    }

    /**
     * O método determina o valor do serviço.
     * @param valor 
     */
    public void setValor(Valores valor) {
        this.valor = valor;
    }

    /**
     * O método determina o pagante do serviço.
     * @return 
     */
    public Usuario getPagante() {
        return pagante;
    }

    /**
     * O método determina o Pagante do serviço.
     * @param pagante 
     */
    public void setPagante(Usuario pagante) {
        this.pagante = pagante;
    }

    /**
     * O método retorna o transportado do serviço.
     * @return 
     */
    public Transportador getDestinatario() {
        return destinatario;
    }

    /**
     * O método determina o transportador do serviço.
     * @param destinatario 
     */
    public void setDestinatario(Transportador destinatario) {
        this.destinatario = destinatario;
    }
    
    
}






































































































































































































































































































































































































































