/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Atores.Controller;


import Mudar.backend.Atores.entity.Usuario;
import Mudar.backend.Atores.repository.UsuarioRepository;
import Mudar.backend.Validator.DateValidator;
import Mudar.backend.Validator.IDMaker;
import Mudar.backend.Validator.TextValidator;
import java.text.SimpleDateFormat;
import java.util.UUID;
import javax.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Rodrigo
 */
@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    @Autowired
    private UsuarioRepository bdusuario;
    
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private final IDMaker id = new IDMaker();
    private DateValidator dv = new DateValidator();
    private TextValidator txt = new TextValidator();
    
    @GetMapping(value = "/teste")
    public ResponseEntity<String> usuario(){
        return ResponseEntity.ok("CRUD de Usuario possível");
    }

    /**
     * Método para cadastro no banco de Usuario.
     * 
     * @param usuario
     * @return
     */
    @PostMapping("")
    public ResponseEntity<Usuario> cadastra(@Valid  @RequestBody Usuario usuario) {
        usuario.setId(id.GeraID());
        usuario.setNome(TextValidator.toTitledCase(usuario.getNome()));
        usuario.setMail(usuario.getMail().toLowerCase());
        return ResponseEntity.ok(bdusuario.getOne(bdusuario.save(usuario).getId()));
    }
    
    /**
     * Método para busca no banco um Usuario.
     * @param id
     * @return 
     */
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> Buscar(@Valid  @PathVariable UUID id) {
            if (bdusuario.existsById(id)) {
                System.out.println("Encontrado para retorno.");
                return ResponseEntity.ok(bdusuario.getOne(id));
            }return ResponseEntity.notFound().build();
    }
    
    /**
     * Método que atualiza no banco os dados do Usuario.
     * @param usuario
     * @return
     */
    @PutMapping("")
    public ResponseEntity<Usuario> Atualizar(@Valid @RequestBody Usuario usuario) {
        if (bdusuario.existsById(usuario.getId())) {
            System.out.println("Encontrado para alteração.");
            Usuario existente = bdusuario.getOne(usuario.getId());
            BeanUtils.copyProperties(usuario, existente, usuario.getId().toString());
            existente = bdusuario.save(existente);
            return ResponseEntity.ok(existente);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Método que deleta no banco os dados do Usuario.
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> Deletar(@Valid  @PathVariable UUID id){
        if (bdusuario.existsById(id)) {
                System.out.println("Encontrado para deletar.");
                return ResponseEntity.noContent().build();
            }return ResponseEntity.notFound().build();
    }
}



















