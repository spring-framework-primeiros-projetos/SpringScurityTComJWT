package Mudar.backend.Emolumento.entity;

import java.util.UUID;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;



/**
 * A Classe Salário refere-se a o pagamento que será efetuado ao ator transportador para pagamento do serviço
 */
@Entity
@Table(name="SALARIO")
public class Salario extends Valores {

    /**
     * A variável agência  aloca a agência fornecida préviamente pelo ator transportador.
     */
    @NotNull(message = "Conta não pode estar vazio.")
    @JoinColumn(name = "CONTA",updatable = false,nullable = false,insertable = false)
    @ManyToOne
    private Contas conta;

    @NotNull(message = "Saldo não pode estar vazio.")
    @JoinColumn(name = "SALDO", updatable = true,nullable = false,insertable = false)
    @ManyToOne
    private Saldo saldo;

    
    /**
     * O método Pagar busca efetuar o pagamento do ator Transportador referente aos valores informado como Agencia e Conta.
     * @param conta
     * @param saldo
    */
    public void Pagar(Contas conta,Saldo saldo ) {

    }

    /**
     * Construtor vazio. não utilizar.
     */
    public Salario() {
    }
    
    /**
     * O construtor Salário será utilizado paga gerar variáveis da classe.
     * @param id
     * @param valor
     * @param conta
     * @param saldo 
     */
    public Salario(UUID id, float valor,Contas conta, Saldo saldo) {
        super(id, valor);
        this.conta = conta;
        this.saldo = saldo;
    }

    
}



























































































































































