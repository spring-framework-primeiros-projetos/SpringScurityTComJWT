/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mudar.backend.Enumeradores;

/**
 *
 * @author Alvaro
 */
public enum Categoria {
    um(1),dois(2),tres(3),quatro(4),cinco(5),seis(6),sete(7),oito(8),nove(9);
    private static String veiculo;
    private static int eixo;
    private static float multiplicador;
    public int valorCategoria;
    
    /**
     * Construtor vazio do enumerador da Categoria.
     * OBS:NÃO DEVE SER USADO
     * @param valorCategoria 
     */
    private Categoria(int valorCategoria) {
        this.valorCategoria = valorCategoria;
    }
    
    /**
     * Método para retornar o veículo.
     * @return 
     */
    public static String getVeiculo() {
        return veiculo;
    }
    
    /**
     * Método para determinar o tipo do veículo.
     * @param veiculo 
     */
    public static void setVeiculo(String veiculo) {
        Categoria.veiculo = veiculo;
    }
    
    /**
     * Método que retorna a quantidade de eixos do veículo.
     * @return 
     */
    public static int getEixo() {
        return eixo;
    }
    
    /**
     * Método que determina o eixo do veículo.
     * @param eixo 
     */
    public static void setEixo(int eixo) {
        Categoria.eixo = eixo;
    }

    /**
     * Método retorna o multiplicador de frete do veículo.
     * @return 
     */
    public static float getMultiplicador() {
        return multiplicador;
    }

    /**
     * Método que determina o multiplicador do veículo.
     * @param multiplicador 
     */
    public static void setMultiplicador(float multiplicador) {
        Categoria.multiplicador = multiplicador;
    }
    
    /**
     * Construtor determinado para gerara a categoria um do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria UM
     */
    public Categoria um(){
        Categoria categoria = Categoria.um;
        setVeiculo("Autos, Caminhonete, Furgão");
        setEixo(2);
        setMultiplicador(1);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria dois do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria DOIS
     */
    public Categoria dois(){
        Categoria categoria = Categoria.dois;
        setVeiculo("Caminhão Leve, Caminhão Trator, Furgão");
        setEixo(2);
        setMultiplicador(2);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria três do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria TRÊS
     */
    public Categoria tres(){
        Categoria categoria = Categoria.tres;
        setVeiculo("Autos ou Caminhonete com semi-reboque");
        setEixo(3);
        setMultiplicador((float) 1.5);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria quatro do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria QUATRO
     */
    public Categoria quatro(){
        Categoria categoria = Categoria.quatro;
        setVeiculo("Caminhão, Caminhão Trator ou Caminhão trator com semi-reboque");
        setEixo(3);
        setMultiplicador(3);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria cinco do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria CINCO
     */
    public Categoria cinco(){
        Categoria categoria = Categoria.cinco;
        setVeiculo("Autos e/ou Caminhonete com reboque");
        setEixo(4);
        setMultiplicador(2);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria seis do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria SEIS
     */
    public Categoria seis(){
        Categoria categoria = Categoria.seis;
        setVeiculo("Caminhão com reboque ou Caminhão Trator com semi-reboque");
        setEixo(4);
        setMultiplicador(4);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria sete do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria SETE
     */
    public Categoria sete(){
        Categoria categoria = Categoria.sete;
        setVeiculo("Caminhão com reboque ou Caminhão Trator com semi-reboque");
        setEixo(5);
        setMultiplicador(5);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria oito do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria OITO
     */
    public Categoria oito(){
        Categoria categoria = Categoria.oito;
        setVeiculo("Caminhão com reboque e Caminhão Trator com semi-reboque");
        setEixo(6);
        setMultiplicador(6);
        return categoria;
    }
    
    /**
     * Construtor determinado para gerara a categoria nove do veículo.
     * Utilizar somente este construtor para determinar esta categoria.
     * @return a categoria NOVE
     */
    public Categoria nove(){
        Categoria categoria = Categoria.nove;
        setVeiculo("Moto, Motoneta, Bicicleta a motor");
        setEixo(2);
        setMultiplicador((float) 0.5);
        return categoria;
    }
}


