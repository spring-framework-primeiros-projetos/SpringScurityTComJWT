package Mudar.backend.Emolumento.entity;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A classe Boleto refere-se a forma de pagamento através de boleto.
 */
@Entity
@Table(name="BOLETO")
public class Boleto extends Valores {

    /**
     * A variável Taxa aloca o a taxa para emissão do boleto que será adicionado no valor final do produto.
     */
    @NotNull(message = "Taxa não pode estar vazio.")
    @Column(name="TAXA",length = 9, unique = false, nullable = true,insertable = false)
    private float taxa;

    /**
     * Construtor vazio, não utilizar.
     */
    public Boleto() {
    }

    /** 
     * Construtor incompleto. usar com precaução.
     * @param taxa 
     */
    public Boleto(float taxa) {
        this.taxa = taxa;
    }

    /**
     * O construtor boleto será utilizado paga gerar variáveis da classe.
     * @param taxa
     * @param id
     * @param valor 
     */
    public Boleto( UUID id, float valor, float taxa) {
        super(id, valor);
        this.taxa = taxa;
    }
    
    

}














































































