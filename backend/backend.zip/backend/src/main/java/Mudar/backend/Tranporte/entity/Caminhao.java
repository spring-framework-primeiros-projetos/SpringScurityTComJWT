package Mudar.backend.Tranporte.entity;



import Mudar.backend.Enumeradores.Categoria;
import Mudar.backend.Enumeradores.Combustivel;
import Mudar.backend.Enumeradores.Estado;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;
/**
 * A classe caminhão visa Retratar a parte motorizada do veículo que transportará os itens necessários.
 * @author Alvaro
 */
@Entity 
@Table(name="CAMINHAO")
@SuppressWarnings("PersistenceUnitPresent")
public class Caminhao implements Serializable {

    /**
     * A Variável placa será o identificador da classe para localizar o veículo.
     */
    @Id
    @Column(name = "ID_CAMINHAO",length = 7, unique = true, nullable = false,insertable = false)
    @NotNull(message = "a placa não foi informada!")
    private String placa;

    /**
     * A variável UF aloca o Estado em que a placa foi emitada.
     */
    @Column(name = "UF", length = 2)
    @Length( max = 2, message = "Estado de emissão da placa não foi informado")
    @NotNull(message = "Estado de emissão da placa não foi informado")
    @Enumerated(EnumType.ORDINAL)
    private Estado uf;

    /**
     * A variável chassi alocará o chassi do caminhão.
     */
    @Column(name = "CHASSI",length = 17)
    @Length( min = 17, max = 17, message = "A quantidade do chassi não foi informada corretamente")    
    @NotNull(message = "O chassi do veiculo não foi informado!")
    private String chassi;

    /**
     * A variável tipo aloca o tipo do veículo.
     */
    @Column(name = "TIPO",length = 1)
    @Enumerated(EnumType.ORDINAL)    
    @NotNull(message = "O tipo do veículo não foi informada")
    private Categoria tipo;

    /**
     * A variável combustível alocará o tipo de combustível do caminhão.
     */
    @Column(name = "COMBUSTIVEL",length = 25)
    @Enumerated(EnumType.ORDINAL)
    @NotNull(message = "O Combustível não foi informado!")
    private Combustivel combustivel;

    /**
     * A variável modelo 
     */
    @Column(name = "MODELO")
    @NotNull(message = "O modelo do veículo não foi informado!")    
    private String modelo;

    /**
     * A variável fabricação de alocará a data de fabricação do veículo.
     */
    @Temporal(TemporalType.DATE)
    @Column(name = "FABRICACAO")
    @NotNull(message = "A data de fabricação do veículo não foi informado!")    
    private Date fabricacao;

    /**
     * A variável maincor do veículo alocará a cor principal do veículo.
     */
    @Column(name = "MAINCOR")
    @NotNull(message = "Informe a cor do veículo.") 
    private String maincor;

    /**
     *  A variável categoria alocará a categoria do veículo.
     */
    @Column(name = "CATEGORIA")
    @NotNull(message = "A categoria do veículo não foi informada!") 
    private Categoria categoria;

    /**
     * Construtor Vazio não utilizar.
     */
    public Caminhao() {
    }

    /**
     *  O construtor da classe caminhão
     * @param placa
     * @param uf
     * @param chassi
     * @param tipo
     * @param combustivel
     * @param modelo
     * @param fabricacao
     * @param maincor
     * @param categoria 
     */
    public Caminhao(String placa, Estado uf, String chassi, Categoria tipo, Combustivel combustivel, String modelo, Date fabricacao, String maincor, Categoria categoria) {
        this.placa = placa;
        this.uf = uf;
        this.chassi = chassi;
        this.tipo = tipo;
        this.combustivel = combustivel;
        this.modelo = modelo;
        this.fabricacao = fabricacao;
        this.maincor = maincor;
        this.categoria = categoria;
    }

    /**
     * O método retorna a a placa do veículo.
     * @return 
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * O método determina a placa do veículo.
     * @param placa 
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * O método retorna o Estado em que o veículo foi emplacado.
     * @return 
     */
    public Estado getUf() {
        return uf;
    }

    /**
     * O método determina o Estado em que o veículo foi emplacado.
     * @param uf 
     */
    public void setUf(Estado uf) {
        this.uf = uf;
    }

    /**
     * O método retorna o número do chassi do veículo.
     * @return 
     */
    public String getChassi() {
        return chassi;
    }

    /**
     * O método determina o chassi do veículo.
     * @param chassi 
     */
    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    /**
     * o método retorna a categoria do veículo.
     * @return 
     */
    public Categoria getTipo() {
        return tipo;
    }

    /**
     *  O método determina a categoria do veículo.
     * @param tipo 
     */
    public void setTipo(Categoria tipo) {
        this.tipo = tipo;
    }

    /**
     * O método retorna o combustível do veículo.
     * @return 
     */
    public Combustivel getCombustivel() {
        return combustivel;
    }

    /**
     * O método determina o combustível do veículo
     * @param combustivel 
     */
    public void setCombustivel(Combustivel combustivel) {
        this.combustivel = combustivel;
    }

    /**
     * o método retorna o modelo do veículo.
     * @return 
     */
    public String getModelo() {
        return modelo;
    }

    /** 
     * O método determina o modelo do veículo. 
     * @param modelo 
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * O método retorna a data de fabricação do veículo.
     * @return 
     */
    public Date getFabricacao() {
        return fabricacao;
    }

    /**
     * O método determina a data de fabricação do veículo.
     * @param fabricacao 
     */
    public void setFabricacao(Date fabricacao) {
        this.fabricacao = fabricacao;
    }

    /**
     * O método retorna a cor principal do veículo.
     * @return 
     */
    public String getMaincor() {
        return maincor;
    }

    /**
     *  o método determina a cor principal do veículo.
     * @param maincor 
     */
    public void setMaincor(String maincor) {
        this.maincor = maincor;
    }

    /**
     * O método retorna a categoria do veículo.
     * @return 
     */
    public Categoria getCategoria() {
        return categoria;
    }

    /** 
     * O método determina a categoria do veiculo.
     * @param categoria 
     */
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
    
    
    
}
