package Mudar.backend.Enumeradores;

/**
 * Esta Classe enumeradora informa o status do serviço solicitado pelo cliente.
 * @author Alvaro
 */
public enum Servico{
    
    /**
     * Neste status do serviço o sistema acusa que o itens estão pendentes.
     */
    itens_pendentes,
    
    /**
     * Neste Status do serviço o sistema acusa que nenhum motorista aceitou o serviço.
     */
    motorista_pendente,
    
    /**
     * Neste status o sistema mostra que há falta de pagamento.
     */
    pagamento_pendente,
    
    /**
     * Neste status o sistema mostra que o processo de transporte não foi iniciado.
     */
    mudanca_pendente,
    
    /**
     * Nesta status o sistema acusa que o motorista já chegou ao ponto de carregamento esta fazendo o carregamento.
     */
    carregando,
    
    /**
     * Neste status o sistema mostra que o caminhão esta no caminho para o endereço determinado.
     */
    no_caminho,
    
    /**
     * Neste status o sistema acusa que processo de entrega foi realizado
     */
    entregue,
    
     /**
     * Nesta status o sistema acusa que o motorista já chegou ao destino esta fazendo o descarregamento.
     */
    descarregando,
    
    /**
     * Neste status informa que o cliente cancelado, finalizando o processo.
     */
    cancelado,
    
    /**
     * Neste status mostra que o sistema foi finalizado com sucesso.
     */
    finalizado;

}
