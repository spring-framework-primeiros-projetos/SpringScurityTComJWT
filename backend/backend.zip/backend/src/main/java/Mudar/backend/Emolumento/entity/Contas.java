package Mudar.backend.Emolumento.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Alvaro
 */
@Entity
@Table(name="CONTA")
public class Contas implements Serializable {
    
    @Id
    @NotNull
    @NotBlank
    @Column(name="ID_CONTA", unique = true, nullable = true,insertable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private UUID Idcon;
    
    @NotNull
    @NotBlank
    @Column(name="AGENCIA")
    private int agencia;
    @NotNull
    @NotBlank
    @Column(name="CONTA")
    private int conta;

    public Contas() {
    }

    public Contas(UUID Idcon, int agencia, int conta) {
        this.agencia = agencia;
        this.conta = conta;
        this.Idcon = Idcon;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }

    public UUID getIdcon() {
        return Idcon;
    }

    public void setIdcon(UUID Idcon) {
        this.Idcon = Idcon;
    }

}







