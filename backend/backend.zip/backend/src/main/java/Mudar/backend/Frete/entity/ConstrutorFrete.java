package Mudar.backend.Frete.entity;

import Mudar.backend.Enumeradores.tipoCarga;
import java.util.UUID;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;



/**
 * A classe especializa ConstrutorFrete busca gerar o custo total do frete para
 * o serviço solicitado pelo ator Solicitante, aonde buscará construir o melhor 
 * frete para o mesmo.
 */
@Entity
@Table(name="ORCAMENTO")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_servico", length = 3, discriminatorType = DiscriminatorType.INTEGER)
@DiscriminatorValue("100")
public class ConstrutorFrete extends ConstrutorFretes {
    @Transient
    private CustoCarga carga;
    @Transient
    private CustoPedagio pedagio;
    @Transient
    private CustoAlimentacao alimentação;

    /**
     * Construtor vazio não utilizar.
     */
    public ConstrutorFrete() {
    }

    /**
     * Construtor utilizado para gerar o calculo total do frete.
     * @param carga
     * @param pedagio
     * @param alimentação
     * @param id 
     */
    public ConstrutorFrete(UUID id, CustoCarga carga, CustoPedagio pedagio, CustoAlimentacao alimentação) {
        super(id);
        this.carga = carga;
        this.pedagio = pedagio;
        this.alimentação = alimentação;
    }

    /**
     * O método retorna a classe Custo da carga.
     * @return 
     */
    public CustoCarga getCarga() {
        return carga;
    }

    /**
     * O método determina a classe Custo da carga.
     * @param carga 
     */
    public void setCarga(CustoCarga carga) {
        this.carga = carga;
    }

    /**
     * O método retorna a classe Custo do Pedágio.
     * @return 
     */
    public CustoPedagio getPedagio() {
        return pedagio;
    }

    /**
     * O método determina a classe Custo do Pedágio.
     * @param pedagio 
     */
    public void setPedagio(CustoPedagio pedagio) {
        this.pedagio = pedagio;
    }

    /** 
     * O método retorna a classe Custo da Alimentação.
     * @return 
     */
    public CustoAlimentacao getAlimentação() {
        return alimentação;
    }
    
    /**
     * O método determina a classe o Custo da Alimentação
     * @param alimentação 
     */
    public void setAlimentação(CustoAlimentacao alimentação) {
        this.alimentação = alimentação;
    }

    /**
     * 
     * @param custo_total
     * @return 
     */
    @Override
    public CustoAlimentacao ConstrutorAlimentacao( float custo_total ) {
            return new CustoAlimentacao(this.getId(), custo_total);
    }

    /**
     * 
     * @param tipoCarga
     * @param distancia
     * @param eixo
     * @param cargaDescarga
     * @param totalCarga
     * @return 
     */
    @Override
    public CustoCarga ConstrutorCarga(tipoCarga tipoCarga,float distancia,int eixo,float cargaDescarga,float totalCarga) {
        return new CustoCarga(this.getId(), tipoCarga, distancia, eixo, cargaDescarga, totalCarga);
    }

    /**
     * 
     * @param valorTotal
     * @param qtd
     * @return 
     */
    @Override
    public CustoPedagio ConstrutorPedagio(float valorTotal,int qtd) {
        return new CustoPedagio(this.getId(), valorTotal, qtd);
    }

}
