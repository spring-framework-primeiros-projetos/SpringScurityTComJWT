package Mudar.backend.Emolumento.entity;





import Mudar.backend.Atores.entity.Transportador;
import Mudar.backend.Atores.entity.Usuario;
import Mudar.backend.Enumeradores.Pagamento;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author Alvaro
 */
@Entity
@Table(name = "PAGAMENTO")  
public class GeraPagamentoFuncionario extends Proventos {

    /**
     * Construtor vazio, não utilizar.
     */
    public GeraPagamentoFuncionario() {
    }

    /**
     * O construtor GeraPagamentoFuncionario será utilizado paga gerar variáveis da classe.
     * @param id
     * @param gerado
     * @param pago
     * @param status
     * @param valor
     * @param pagante
     * @param destinatario 
     */
    public GeraPagamentoFuncionario(UUID id, Date gerado, Date pago, Pagamento status, Salario valor, Usuario pagante, Transportador destinatario) {
        super(id, gerado, pago, status, valor, pagante, destinatario);
    }

    
    @Override
    public GeraPagamento pagamento() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
























































